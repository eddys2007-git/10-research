import streamlit as st
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import pickle
from datetime import datetime
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def show_data_loading_preprocessing(dataset_dir="dataset", result_dir="result"):
    """
    Data Loading & Preprocessing for REIT Forecasting
    Combines all datasets, calculates log-returns and yield-changes,
    aligns time-series, and prepares final dataset for LSTM, TVP-VAR, and SHAP.
    """
    
    st.title("📊 Data Loading & Preprocessing")
    st.markdown("""
    ### REIT Forecasting - Data Preparation Module
    
    This module performs comprehensive preprocessing:
    - Combines all asset datasets (VNQ, SPY, IEF, TNX, VIX, HYG)
    - Calculates log-returns and yield-changes
    - Aligns all time-series via inner join
    - Splits data into train/validation/test sets
    - Applies StandardScaler for LSTM modeling
    """)
    
    # Ensure result directory exists
    prep_dir = os.path.join(result_dir, "data_prep")
    os.makedirs(prep_dir, exist_ok=True)
    
    # Display available datasets
    st.subheader("📁 Available Datasets")
    available_files = [f for f in os.listdir(dataset_dir) if f.endswith('.csv')]
    
    if not available_files:
        st.error(f"No CSV files found in {dataset_dir}")
        return
    
    # Create a mapping of expected symbols
    symbol_mapping = {
        'VNQ.csv': 'VNQ',
        'SPY.csv': 'SPY',
        '^GSPC.csv': 'SPY',  # Alternative for S&P 500
        'IEF.csv': 'IEF',
        '^TNX.csv': 'TNX',
        '^VIX.csv': 'VIX',
        'HYG.csv': 'HYG'
    }
    
    # Show available files
    col1, col2 = st.columns(2)
    with col1:
        st.write("**Files in dataset folder:**")
        for f in sorted(available_files):
            symbol = symbol_mapping.get(f, f.replace('.csv', ''))
            st.write(f"✓ {f} → {symbol}")
    
    with col2:
        st.write("**Expected assets:**")
        st.write("• VNQ (REIT ETF)")
        st.write("• SPY/^GSPC (Market Index)")
        st.write("• IEF (Bond ETF)")
        st.write("• ^TNX (10-Year Yield)")
        st.write("• ^VIX (Volatility Index)")
        st.write("• HYG (Credit Spread ETF) - Optional")
    
    st.markdown("---")
    
    # Main preprocessing button
    if st.button("🚀 Run Preprocessing", type="primary", use_container_width=True):
        
        log_messages = []
        log_messages.append(f"=== Preprocessing Started at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        
        with st.spinner("Processing datasets..."):
            
            # Step 1: Load and standardize all datasets
            st.subheader("Step 1: Loading Datasets")
            progress_bar = st.progress(0)
            
            all_dataframes = []
            total_files = len(available_files)
            
            for idx, file in enumerate(available_files):
                file_path = os.path.join(dataset_dir, file)
                symbol = symbol_mapping.get(file, file.replace('.csv', ''))
                
                try:
                    # Read CSV
                    df = pd.read_csv(file_path)
                    
                    # Standardize column names to lowercase
                    df.columns = df.columns.str.lower()
                    
                    # Handle date column
                    if 'date' not in df.columns:
                        # Try to find date-like column
                        date_cols = [col for col in df.columns if 'date' in col.lower() or col.lower() == 'timestamp']
                        if date_cols:
                            df.rename(columns={date_cols[0]: 'date'}, inplace=True)
                        else:
                            # Assume first column is date
                            df.rename(columns={df.columns[0]: 'date'}, inplace=True)
                    
                    # Convert to datetime
                    df['date'] = pd.to_datetime(df['date'])
                    
                    # Add symbol column
                    df['symbol'] = symbol
                    
                    # Sort by date
                    df = df.sort_values('date').reset_index(drop=True)
                    
                    # Select relevant columns
                    cols_to_keep = ['symbol', 'date']
                    for col in ['adjclose', 'close', 'open', 'high', 'low', 'volume']:
                        if col in df.columns:
                            cols_to_keep.append(col)
                    
                    df = df[cols_to_keep].copy()
                    
                    all_dataframes.append(df)
                    
                    st.success(f"✓ Loaded {symbol}: {len(df)} rows from {df['date'].min().date()} to {df['date'].max().date()}")
                    log_messages.append(f"Loaded {symbol}: {len(df)} rows\n")
                    
                except Exception as e:
                    st.error(f"✗ Error loading {file}: {str(e)}")
                    log_messages.append(f"ERROR loading {file}: {str(e)}\n")
                
                progress_bar.progress((idx + 1) / total_files)
            
            if not all_dataframes:
                st.error("No datasets were successfully loaded!")
                return
            
            # Step 2: Combine all datasets
            st.subheader("Step 2: Combining Datasets")
            combined_df = pd.concat(all_dataframes, ignore_index=True)
            combined_df = combined_df.sort_values(['symbol', 'date']).reset_index(drop=True)
            
            st.success(f"✓ Combined dataset: {len(combined_df)} total rows across {combined_df['symbol'].nunique()} symbols")
            log_messages.append(f"Combined dataset: {len(combined_df)} rows, {combined_df['symbol'].nunique()} symbols\n")
            
            # Save combined_df
            combined_path = os.path.join(prep_dir, "combined_df.csv")
            combined_df.to_csv(combined_path, index=False)
            st.info(f"💾 Saved: {combined_path}")
            
            # Step 3: Calculate log-returns and yield-changes
            st.subheader("Step 3: Calculating Returns")
            
            returns_list = []
            
            for symbol in combined_df['symbol'].unique():
                symbol_df = combined_df[combined_df['symbol'] == symbol].copy()
                symbol_df = symbol_df.sort_values('date').reset_index(drop=True)
                
                # Determine which column to use for price
                price_col = 'adjclose' if 'adjclose' in symbol_df.columns else 'close'
                
                if symbol == 'TNX':
                    # For Treasury Yield, calculate yield change
                    symbol_df['yield_close'] = symbol_df[price_col]
                    symbol_df['yield_change'] = symbol_df['yield_close'].diff()
                    symbol_df['feature_value'] = symbol_df['yield_change']
                    symbol_df['feature_name'] = 'yield_change'
                else:
                    # For price-based assets, calculate log-return
                    symbol_df['log_return'] = np.log(symbol_df[price_col] / symbol_df[price_col].shift(1))
                    symbol_df['feature_value'] = symbol_df['log_return']
                    symbol_df['feature_name'] = 'log_return'
                
                # Keep relevant columns
                result_df = symbol_df[['symbol', 'date', price_col, 'feature_name', 'feature_value']].copy()
                result_df.rename(columns={price_col: 'price'}, inplace=True)
                
                returns_list.append(result_df)
                
                st.write(f"✓ {symbol}: Calculated {'yield_change' if symbol == 'TNX' else 'log_return'}")
                log_messages.append(f"Calculated features for {symbol}\n")
            
            returns_df = pd.concat(returns_list, ignore_index=True)
            returns_df = returns_df.dropna(subset=['feature_value'])
            
            # Step 4: Pivot and align all variables
            st.subheader("Step 4: Aligning Time-Series (Inner Join)")
            
            # Create pivot table
            pivot_df = returns_df.pivot_table(
                index='date',
                columns='symbol',
                values='feature_value',
                aggfunc='first'
            ).reset_index()
            
            # Rename columns to be more descriptive
            new_columns = {'date': 'date'}
            for col in pivot_df.columns:
                if col != 'date':
                    if col == 'TNX':
                        new_columns[col] = 'yield_change_TNX'
                    else:
                        new_columns[col] = f'log_return_{col}'
            
            pivot_df.rename(columns=new_columns, inplace=True)
            
            # Inner join: drop any rows with missing values
            aligned_df = pivot_df.dropna().reset_index(drop=True)
            
            st.success(f"✓ Aligned dataset: {len(aligned_df)} rows with complete data across all variables")
            st.info(f"📉 Dropped {len(pivot_df) - len(aligned_df)} rows due to missing values (inner join)")
            log_messages.append(f"Aligned dataset: {len(aligned_df)} rows after inner join\n")
            log_messages.append(f"Date range: {aligned_df['date'].min()} to {aligned_df['date'].max()}\n")
            
            # Save aligned_df
            aligned_path = os.path.join(prep_dir, "aligned_df.csv")
            aligned_df.to_csv(aligned_path, index=False)
            st.info(f"💾 Saved: {aligned_path}")
            
            # Step 5: Train/Validation/Test Split
            st.subheader("Step 5: Train/Validation/Test Split")
            
            total_rows = len(aligned_df)
            train_size = int(total_rows * 0.70)
            val_size = int(total_rows * 0.15)
            
            train_df = aligned_df.iloc[:train_size].copy()
            val_df = aligned_df.iloc[train_size:train_size + val_size].copy()
            test_df = aligned_df.iloc[train_size + val_size:].copy()
            
            st.write(f"**Train Set:** {len(train_df)} rows ({len(train_df)/total_rows*100:.1f}%) - {train_df['date'].min().date()} to {train_df['date'].max().date()}")
            st.write(f"**Validation Set:** {len(val_df)} rows ({len(val_df)/total_rows*100:.1f}%) - {val_df['date'].min().date()} to {val_df['date'].max().date()}")
            st.write(f"**Test Set:** {len(test_df)} rows ({len(test_df)/total_rows*100:.1f}%) - {test_df['date'].min().date()} to {test_df['date'].max().date()}")
            
            log_messages.append(f"\nData Split:\n")
            log_messages.append(f"  Train: {len(train_df)} rows\n")
            log_messages.append(f"  Val: {len(val_df)} rows\n")
            log_messages.append(f"  Test: {len(test_df)} rows\n")
            
            # Save splits
            train_path = os.path.join(prep_dir, "train_df.csv")
            val_path = os.path.join(prep_dir, "val_df.csv")
            test_path = os.path.join(prep_dir, "test_df.csv")
            
            train_df.to_csv(train_path, index=False)
            val_df.to_csv(val_path, index=False)
            test_df.to_csv(test_path, index=False)
            
            st.info(f"💾 Saved: {train_path}, {val_path}, {test_path}")
            
            # Step 6: StandardScaler for LSTM
            st.subheader("Step 6: Applying StandardScaler")
            
            # Get feature columns (exclude date)
            feature_cols = [col for col in aligned_df.columns if col != 'date']
            
            # Fit scaler on training data
            scaler = StandardScaler()
            train_features = train_df[feature_cols].values
            scaler.fit(train_features)
            
            # Transform all sets
            train_scaled = scaler.transform(train_df[feature_cols].values)
            val_scaled = scaler.transform(val_df[feature_cols].values)
            test_scaled = scaler.transform(test_df[feature_cols].values)
            
            # Create scaled dataframes
            train_scaled_df = pd.DataFrame(train_scaled, columns=feature_cols)
            train_scaled_df.insert(0, 'date', train_df['date'].values)
            
            val_scaled_df = pd.DataFrame(val_scaled, columns=feature_cols)
            val_scaled_df.insert(0, 'date', val_df['date'].values)
            
            test_scaled_df = pd.DataFrame(test_scaled, columns=feature_cols)
            test_scaled_df.insert(0, 'date', test_df['date'].values)
            
            # Save scaled data
            train_scaled_path = os.path.join(prep_dir, "train_scaled.csv")
            val_scaled_path = os.path.join(prep_dir, "val_scaled.csv")
            test_scaled_path = os.path.join(prep_dir, "test_scaled.csv")
            
            train_scaled_df.to_csv(train_scaled_path, index=False)
            val_scaled_df.to_csv(val_scaled_path, index=False)
            test_scaled_df.to_csv(test_scaled_path, index=False)
            
            # Save scaler
            scaler_path = os.path.join(prep_dir, "scaler.pkl")
            with open(scaler_path, 'wb') as f:
                pickle.dump(scaler, f)
            
            st.success(f"✓ StandardScaler fitted on {len(feature_cols)} features")
            st.info(f"💾 Saved scaled datasets and scaler.pkl")
            
            log_messages.append(f"\nStandardScaler applied to {len(feature_cols)} features\n")
            log_messages.append(f"Features: {', '.join(feature_cols)}\n")
            
            # Save preprocessing log
            log_path = os.path.join(prep_dir, "preprocessing_log.txt")
            log_messages.append(f"\n=== Preprocessing Completed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            
            with open(log_path, 'w') as f:
                f.writelines(log_messages)
            
            st.success("✅ **Data preprocessing completed successfully!**")
            st.info(f"📁 All files saved in: `{prep_dir}/`")
            
            # Display results
            st.markdown("---")
            st.subheader("📊 Preprocessing Results")
            
            # Tabs for different views
            tab1, tab2, tab3, tab4, tab5 = st.tabs([
                "Preview Data", 
                "Missing Values", 
                "Statistics", 
                "Visualizations",
                "Files Summary"
            ])
            
            with tab1:
                st.write("**Combined Dataset (First 20 rows)**")
                st.dataframe(combined_df.head(20), use_container_width=True)
                
                st.write("**Aligned Dataset (First 20 rows)**")
                st.dataframe(aligned_df.head(20), use_container_width=True)
                
                st.write("**Train Set (First 20 rows)**")
                st.dataframe(train_df.head(20), use_container_width=True)
            
            with tab2:
                st.write("**Missing Values Summary**")
                
                # Check missing values in combined_df
                missing_combined = combined_df.isnull().sum()
                missing_combined = missing_combined[missing_combined > 0]
                
                if len(missing_combined) > 0:
                    missing_df = pd.DataFrame({
                        'Feature': missing_combined.index,
                        'Missing Count': missing_combined.values,
                        'Percentage': (missing_combined.values / len(combined_df) * 100).round(2)
                    })
                    st.dataframe(missing_df, use_container_width=True)
                else:
                    st.success("✓ No missing values in combined dataset")
                
                # Check aligned dataset
                st.write("**Aligned Dataset (After Inner Join)**")
                missing_aligned = aligned_df.isnull().sum()
                missing_aligned = missing_aligned[missing_aligned > 0]
                
                if len(missing_aligned) > 0:
                    st.warning("Warning: Missing values found after alignment")
                    st.dataframe(pd.DataFrame({
                        'Feature': missing_aligned.index,
                        'Missing Count': missing_aligned.values
                    }), use_container_width=True)
                else:
                    st.success("✓ No missing values in aligned dataset")
            
            with tab3:
                st.write("**Descriptive Statistics - Aligned Dataset**")
                st.dataframe(aligned_df.describe(), use_container_width=True)
                
                st.write("**Descriptive Statistics - Train Set (Scaled)**")
                st.dataframe(train_scaled_df.describe(), use_container_width=True)
            
            with tab4:
                st.write("**Visualizations for VNQ (REIT ETF)**")
                
                # Get VNQ data
                vnq_data = combined_df[combined_df['symbol'] == 'VNQ'].copy()
                vnq_returns = returns_df[returns_df['symbol'] == 'VNQ'].copy()
                
                if len(vnq_data) > 0:
                    # Create subplots
                    fig = make_subplots(
                        rows=2, cols=1,
                        subplot_titles=('VNQ Adjusted Close Price', 'VNQ Log Returns'),
                        vertical_spacing=0.12,
                        row_heights=[0.5, 0.5]
                    )
                    
                    # Price chart
                    price_col = 'adjclose' if 'adjclose' in vnq_data.columns else 'close'
                    fig.add_trace(
                        go.Scatter(
                            x=vnq_data['date'],
                            y=vnq_data[price_col],
                            mode='lines',
                            name='Adj Close',
                            line=dict(color='blue', width=1.5)
                        ),
                        row=1, col=1
                    )
                    
                    # Log returns chart
                    if len(vnq_returns) > 0:
                        fig.add_trace(
                            go.Scatter(
                                x=vnq_returns['date'],
                                y=vnq_returns['feature_value'],
                                mode='lines',
                                name='Log Return',
                                line=dict(color='green', width=1)
                            ),
                            row=2, col=1
                        )
                    
                    fig.update_xaxes(title_text="Date", row=2, col=1)
                    fig.update_yaxes(title_text="Price ($)", row=1, col=1)
                    fig.update_yaxes(title_text="Log Return", row=2, col=1)
                    
                    fig.update_layout(
                        height=700,
                        showlegend=True,
                        hovermode='x unified'
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                # TNX yield change chart
                st.write("**10-Year Treasury Yield Change (TNX)**")
                tnx_data = combined_df[combined_df['symbol'] == 'TNX'].copy()
                tnx_returns = returns_df[returns_df['symbol'] == 'TNX'].copy()
                
                if len(tnx_data) > 0:
                    fig2 = make_subplots(
                        rows=2, cols=1,
                        subplot_titles=('TNX Yield Level', 'TNX Yield Change'),
                        vertical_spacing=0.12
                    )
                    
                    price_col = 'adjclose' if 'adjclose' in tnx_data.columns else 'close'
                    fig2.add_trace(
                        go.Scatter(
                            x=tnx_data['date'],
                            y=tnx_data[price_col],
                            mode='lines',
                            name='Yield',
                            line=dict(color='red', width=1.5)
                        ),
                        row=1, col=1
                    )
                    
                    if len(tnx_returns) > 0:
                        fig2.add_trace(
                            go.Scatter(
                                x=tnx_returns['date'],
                                y=tnx_returns['feature_value'],
                                mode='lines',
                                name='Yield Change',
                                line=dict(color='orange', width=1)
                            ),
                            row=2, col=1
                        )
                    
                    fig2.update_xaxes(title_text="Date", row=2, col=1)
                    fig2.update_yaxes(title_text="Yield (%)", row=1, col=1)
                    fig2.update_yaxes(title_text="Change", row=2, col=1)
                    
                    fig2.update_layout(height=700, showlegend=True, hovermode='x unified')
                    st.plotly_chart(fig2, use_container_width=True)
            
            with tab5:
                st.write("**Generated Files Summary**")
                
                files_info = [
                    ("combined_df.csv", "Raw merged dataset with all symbols"),
                    ("aligned_df.csv", "Time-aligned dataset (inner join)"),
                    ("train_df.csv", "Training set (70%)"),
                    ("val_df.csv", "Validation set (15%)"),
                    ("test_df.csv", "Test set (15%)"),
                    ("train_scaled.csv", "Scaled training set"),
                    ("val_scaled.csv", "Scaled validation set"),
                    ("test_scaled.csv", "Scaled test set"),
                    ("scaler.pkl", "StandardScaler object"),
                    ("preprocessing_log.txt", "Processing log file")
                ]
                
                files_df = pd.DataFrame(files_info, columns=['Filename', 'Description'])
                st.dataframe(files_df, use_container_width=True)
                
                st.success(f"✅ All {len(files_info)} files saved successfully in `{prep_dir}/`")
