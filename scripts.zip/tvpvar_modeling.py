import streamlit as st
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.api import VAR
from statsmodels.tools.eval_measures import rmse, meanabs
import warnings
warnings.filterwarnings('ignore')

def show_tvpvar_modeling(result_dir="result", summary_dir="result_summary"):
    """
    TVP-VAR Modeling Module for REIT Forecasting
    
    Implements rolling window VAR (approximation of TVP-VAR) with:
    - Automatic lag selection via AIC
    - One-step-ahead forecasting
    - Comprehensive error analysis
    - Publication-ready visualizations
    """
    
    st.title("📈 TVP-VAR Modeling")
    st.markdown("""
    ### Time-Varying Parameter VAR for REIT Forecasting
    
    This module implements **rolling window VAR** as an approximation of TVP-VAR:
    - Automatic lag selection using AIC
    - Expanding window one-step-ahead forecasting
    - Comprehensive error metrics and directional accuracy
    - Publication-ready figures for MDPI manuscript
    """)
    
    # Ensure directories exist
    tvpvar_dir = os.path.join(result_dir, "tvpvar")
    os.makedirs(tvpvar_dir, exist_ok=True)
    os.makedirs(summary_dir, exist_ok=True)
    
    # Check for preprocessed data
    data_prep_dir = os.path.join(result_dir, "data_prep")
    train_path = os.path.join(data_prep_dir, "train_df.csv")
    val_path = os.path.join(data_prep_dir, "val_df.csv")
    test_path = os.path.join(data_prep_dir, "test_df.csv")
    
    # Check if files exist
    files_exist = all([
        os.path.exists(train_path),
        os.path.exists(val_path),
        os.path.exists(test_path)
    ])
    
    if not files_exist:
        st.error("⚠️ Preprocessed data not found!")
        st.info("Please run **Data Loading & Preprocessing** first to generate the required files.")
        st.markdown("""
        Required files:
        - `result/data_prep/train_df.csv`
        - `result/data_prep/val_df.csv`
        - `result/data_prep/test_df.csv`
        """)
        return
    
    st.success("✓ Preprocessed data found")
    
    # Configuration section
    st.subheader("⚙️ Model Configuration")
    
    col1, col2 = st.columns(2)
    with col1:
        max_lag = st.slider("Maximum Lag for AIC Selection", 1, 12, 8)
        target_var = st.selectbox("Target Variable", 
                                   ["log_return_VNQ", "log_return_SPY"],
                                   index=0)
    
    with col2:
        st.write("**Variables to Include:**")
        include_spy = st.checkbox("log_return_SPY", value=True)
        include_ief = st.checkbox("log_return_IEF", value=True)
        include_tnx = st.checkbox("yield_change_TNX", value=True)
        include_vix = st.checkbox("log_return_VIX", value=True)
        include_hyg = st.checkbox("log_return_HYG", value=True)
    
    st.markdown("---")
    
    # Main execution button
    if st.button("🚀 Run TVP-VAR Model", type="primary", use_container_width=True):
        
        with st.spinner("Loading and preparing data..."):
            
            # Step 1: Load data
            st.subheader("Step 1: Loading Data")
            
            try:
                train_df = pd.read_csv(train_path)
                val_df = pd.read_csv(val_path)
                test_df = pd.read_csv(test_path)
                
                # Combine train + val for full training set
                full_train_df = pd.concat([train_df, val_df], ignore_index=True)
                
                st.success(f"✓ Loaded data: Train={len(train_df)}, Val={len(val_df)}, Test={len(test_df)}")
                st.info(f"📊 Full training set: {len(full_train_df)} rows")
                
            except Exception as e:
                st.error(f"Error loading data: {str(e)}")
                return
        
        with st.spinner("Selecting variables..."):
            
            # Step 2: Select variables
            st.subheader("Step 2: Variable Selection")
            
            # Build variable list
            variables = [target_var]
            
            if include_spy and target_var != "log_return_SPY":
                if "log_return_SPY" in full_train_df.columns:
                    variables.append("log_return_SPY")
            
            if include_ief and "log_return_IEF" in full_train_df.columns:
                variables.append("log_return_IEF")
            
            if include_tnx and "yield_change_TNX" in full_train_df.columns:
                variables.append("yield_change_TNX")
            
            if include_vix and "log_return_VIX" in full_train_df.columns:
                variables.append("log_return_VIX")
            
            if include_hyg and "log_return_HYG" in full_train_df.columns:
                variables.append("log_return_HYG")
            
            # Remove duplicates and check availability
            variables = list(dict.fromkeys(variables))
            available_vars = [v for v in variables if v in full_train_df.columns]
            
            if len(available_vars) < 2:
                st.error("Need at least 2 variables for VAR modeling")
                return
            
            st.success(f"✓ Selected {len(available_vars)} variables: {', '.join(available_vars)}")
            
            # Prepare data matrices
            train_data = full_train_df[available_vars].dropna()
            test_data = test_df[available_vars].dropna()
            
            if 'date' in full_train_df.columns:
                train_dates = full_train_df.loc[train_data.index, 'date']
                test_dates = test_df.loc[test_data.index, 'date']
            else:
                train_dates = None
                test_dates = pd.date_range(start='2020-01-01', periods=len(test_data), freq='D')
            
            st.write(f"**Training data shape:** {train_data.shape}")
            st.write(f"**Test data shape:** {test_data.shape}")
        
        with st.spinner("Selecting optimal lag using AIC..."):
            
            # Step 3: Lag selection
            st.subheader("Step 3: Lag Selection (AIC)")
            
            lag_results = []
            
            progress_bar = st.progress(0)
            
            for lag in range(1, max_lag + 1):
                try:
                    model = VAR(train_data)
                    fitted = model.fit(lag)
                    aic_value = fitted.aic
                    lag_results.append({'lag': lag, 'aic': aic_value})
                    
                except Exception as e:
                    st.warning(f"Could not fit lag {lag}: {str(e)}")
                
                progress_bar.progress(lag / max_lag)
            
            if not lag_results:
                st.error("Failed to fit any VAR models")
                return
            
            lag_df = pd.DataFrame(lag_results)
            optimal_lag = lag_df.loc[lag_df['aic'].idxmin(), 'lag']
            optimal_aic = lag_df.loc[lag_df['aic'].idxmin(), 'aic']
            
            st.success(f"✓ Optimal lag selected: **{int(optimal_lag)}** (AIC = {optimal_aic:.2f})")
            
            # Save lag selection results
            lag_path = os.path.join(summary_dir, "tvpvar_lag_selection.csv")
            lag_df.to_csv(lag_path, index=False)
            st.info(f"💾 Saved: {lag_path}")
            
            # Display lag selection
            col1, col2 = st.columns([1, 1])
            
            with col1:
                st.write("**Lag Selection Results:**")
                st.dataframe(lag_df, use_container_width=True)
            
            with col2:
                st.write("**AIC vs Lag:**")
                fig_lag, ax_lag = plt.subplots(figsize=(6, 4))
                ax_lag.plot(lag_df['lag'], lag_df['aic'], marker='o', linewidth=2)
                ax_lag.axvline(optimal_lag, color='red', linestyle='--', label=f'Optimal Lag={int(optimal_lag)}')
                ax_lag.set_xlabel('Lag')
                ax_lag.set_ylabel('AIC')
                ax_lag.set_title('AIC vs Lag Order')
                ax_lag.legend()
                ax_lag.grid(True, alpha=0.3)
                st.pyplot(fig_lag)
                plt.close()
        
        with st.spinner("Running rolling window VAR forecasting..."):
            
            # Step 4: Rolling window forecasting
            st.subheader("Step 4: Rolling Window Forecasting")
            
            predictions = []
            actuals = []
            dates = []
            errors = []
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Use optimal lag
            lag = int(optimal_lag)
            
            # Rolling window (expanding)
            for i in range(len(test_data)):
                
                status_text.text(f"Forecasting step {i+1}/{len(test_data)}...")
                
                try:
                    # Expanding window: use all data up to current point
                    train_window = pd.concat([train_data, test_data.iloc[:i]], ignore_index=True)
                    
                    # Fit VAR model
                    model = VAR(train_window)
                    fitted = model.fit(lag)
                    
                    # Forecast 1 step ahead
                    forecast = fitted.forecast(train_window.values[-lag:], steps=1)
                    
                    # Get prediction for target variable
                    target_idx = available_vars.index(target_var)
                    pred_value = forecast[0, target_idx]
                    actual_value = test_data.iloc[i][target_var]
                    
                    predictions.append(pred_value)
                    actuals.append(actual_value)
                    
                    if test_dates is not None:
                        dates.append(test_dates.iloc[i])
                    else:
                        dates.append(i)
                    
                    errors.append(actual_value - pred_value)
                    
                except Exception as e:
                    st.warning(f"Error at step {i}: {str(e)}")
                    predictions.append(np.nan)
                    actuals.append(test_data.iloc[i][target_var])
                    dates.append(test_dates.iloc[i] if test_dates is not None else i)
                    errors.append(np.nan)
                
                progress_bar.progress((i + 1) / len(test_data))
            
            status_text.empty()
            
            # Create results dataframe
            results_df = pd.DataFrame({
                'date': dates,
                'actual': actuals,
                'forecast': predictions,
                'error': errors
            })
            
            # Remove NaN rows
            results_df = results_df.dropna()
            
            if len(results_df) == 0:
                st.error("No valid predictions generated")
                return
            
            st.success(f"✓ Generated {len(results_df)} forecasts")
            
            # Save predictions
            pred_path = os.path.join(tvpvar_dir, "tvpvar_predictions.csv")
            results_df.to_csv(pred_path, index=False)
            st.info(f"💾 Saved: {pred_path}")
        
        with st.spinner("Calculating error metrics..."):
            
            # Step 5: Error analysis
            st.subheader("Step 5: Error Analysis")
            
            # Calculate additional error metrics
            results_df['abs_error'] = results_df['error'].abs()
            results_df['sq_error'] = results_df['error'] ** 2
            
            # Summary statistics
            error_stats = {
                'mean_error': results_df['error'].mean(),
                'std_error': results_df['error'].std(),
                'rmse': np.sqrt(results_df['sq_error'].mean()),
                'mae': results_df['abs_error'].mean(),
                'max_error': results_df['error'].max(),
                'min_error': results_df['error'].min(),
                'median_error': results_df['error'].median()
            }
            
            error_stats_df = pd.DataFrame([error_stats])
            
            # Save error statistics
            error_stats_path = os.path.join(tvpvar_dir, "tvpvar_error_stats.csv")
            error_stats_df.to_csv(error_stats_path, index=False)
            st.info(f"💾 Saved: {error_stats_path}")
            
            # Display error statistics
            st.write("**Error Statistics:**")
            
            col1, col2, col3, col4 = st.columns(4)
            col1.metric("RMSE", f"{error_stats['rmse']:.6f}")
            col2.metric("MAE", f"{error_stats['mae']:.6f}")
            col3.metric("Mean Error", f"{error_stats['mean_error']:.6f}")
            col4.metric("Std Error", f"{error_stats['std_error']:.6f}")
            
            st.dataframe(error_stats_df, use_container_width=True)
        
        with st.spinner("Calculating directional accuracy..."):
            
            # Step 6: Directional accuracy
            st.subheader("Step 6: Directional Accuracy")
            
            # Calculate direction match
            results_df['actual_direction'] = np.sign(results_df['actual'])
            results_df['forecast_direction'] = np.sign(results_df['forecast'])
            results_df['direction_match'] = (results_df['actual_direction'] == results_df['forecast_direction']).astype(int)
            
            directional_accuracy = results_df['direction_match'].mean()
            
            dir_acc_df = pd.DataFrame({
                'metric': ['directional_accuracy'],
                'value': [directional_accuracy]
            })
            
            # Save directional accuracy
            dir_acc_path = os.path.join(tvpvar_dir, "tvpvar_directional_accuracy.csv")
            dir_acc_df.to_csv(dir_acc_path, index=False)
            st.info(f"💾 Saved: {dir_acc_path}")
            
            # Display
            st.metric("Directional Accuracy", f"{directional_accuracy:.2%}")
            
            if directional_accuracy > 0.5:
                st.success(f"✓ Model predicts direction correctly {directional_accuracy:.1%} of the time")
            else:
                st.warning(f"⚠ Model predicts direction correctly only {directional_accuracy:.1%} of the time")
        
        with st.spinner("Generating publication-ready figures..."):
            
            # Step 7: Generate figures
            st.subheader("Step 7: Publication-Ready Visualizations")
            
            # Set style for publication
            plt.style.use('seaborn-v0_8-darkgrid')
            sns.set_palette("husl")
            
            # Figure A: Actual vs Forecast
            fig_pred, ax_pred = plt.subplots(figsize=(12, 6))
            ax_pred.plot(results_df['date'], results_df['actual'], 
                        label='Actual', linewidth=2, alpha=0.8)
            ax_pred.plot(results_df['date'], results_df['forecast'], 
                        label='Forecast', linewidth=2, alpha=0.8, linestyle='--')
            ax_pred.set_xlabel('Date', fontsize=12)
            ax_pred.set_ylabel(f'{target_var}', fontsize=12)
            ax_pred.set_title('TVP-VAR: Actual vs Forecast', fontsize=14, fontweight='bold')
            ax_pred.legend(fontsize=11)
            ax_pred.grid(True, alpha=0.3)
            plt.xticks(rotation=45)
            plt.tight_layout()
            
            pred_fig_path = os.path.join(summary_dir, "tvpvar_actual_vs_pred.png")
            fig_pred.savefig(pred_fig_path, dpi=300, bbox_inches='tight')
            st.pyplot(fig_pred)
            plt.close()
            st.info(f"💾 Saved: {pred_fig_path}")
            
            # Figure B: Residual Histogram
            fig_hist, ax_hist = plt.subplots(figsize=(10, 6))
            ax_hist.hist(results_df['error'], bins=30, edgecolor='black', alpha=0.7)
            ax_hist.axvline(0, color='red', linestyle='--', linewidth=2, label='Zero Error')
            ax_hist.set_xlabel('Residual (Error)', fontsize=12)
            ax_hist.set_ylabel('Frequency', fontsize=12)
            ax_hist.set_title('TVP-VAR: Residual Distribution', fontsize=14, fontweight='bold')
            ax_hist.legend(fontsize=11)
            ax_hist.grid(True, alpha=0.3, axis='y')
            plt.tight_layout()
            
            hist_fig_path = os.path.join(summary_dir, "tvpvar_residual_hist.png")
            fig_hist.savefig(hist_fig_path, dpi=300, bbox_inches='tight')
            st.pyplot(fig_hist)
            plt.close()
            st.info(f"💾 Saved: {hist_fig_path}")
            
            # Figure C: Rolling MAE
            window_size = min(20, len(results_df) // 5)
            results_df['rolling_mae'] = results_df['abs_error'].rolling(window=window_size, min_periods=1).mean()
            
            fig_rolling, ax_rolling = plt.subplots(figsize=(12, 6))
            ax_rolling.plot(results_df['date'], results_df['rolling_mae'], 
                           linewidth=2, color='darkblue')
            ax_rolling.axhline(results_df['abs_error'].mean(), 
                              color='red', linestyle='--', linewidth=2, 
                              label=f'Overall MAE={results_df["abs_error"].mean():.6f}')
            ax_rolling.set_xlabel('Date', fontsize=12)
            ax_rolling.set_ylabel(f'Rolling MAE (window={window_size})', fontsize=12)
            ax_rolling.set_title('TVP-VAR: Rolling Mean Absolute Error', fontsize=14, fontweight='bold')
            ax_rolling.legend(fontsize=11)
            ax_rolling.grid(True, alpha=0.3)
            plt.xticks(rotation=45)
            plt.tight_layout()
            
            rolling_fig_path = os.path.join(summary_dir, "tvpvar_rolling_mae.png")
            fig_rolling.savefig(rolling_fig_path, dpi=300, bbox_inches='tight')
            st.pyplot(fig_rolling)
            plt.close()
            st.info(f"💾 Saved: {rolling_fig_path}")
            
            # Additional: Boxplot of residuals
            st.write("**Residual Boxplot:**")
            fig_box, ax_box = plt.subplots(figsize=(8, 6))
            ax_box.boxplot(results_df['error'], vert=True)
            ax_box.set_ylabel('Residual', fontsize=12)
            ax_box.set_title('TVP-VAR: Residual Boxplot', fontsize=14, fontweight='bold')
            ax_box.grid(True, alpha=0.3, axis='y')
            plt.tight_layout()
            st.pyplot(fig_box)
            plt.close()
        
        with st.spinner("Exporting summary files for manuscript..."):
            
            # Step 8: Export summary files
            st.subheader("Step 8: Export Summary for Manuscript")
            
            # Full summary
            full_summary = {
                'rmse': error_stats['rmse'],
                'mae': error_stats['mae'],
                'mean_error': error_stats['mean_error'],
                'std_error': error_stats['std_error'],
                'directional_accuracy': directional_accuracy,
                'optimal_lag': int(optimal_lag),
                'n_forecasts': len(results_df),
                'target_variable': target_var,
                'n_variables': len(available_vars)
            }
            
            full_summary_df = pd.DataFrame([full_summary])
            full_summary_path = os.path.join(summary_dir, "tvpvar_full_summary.csv")
            full_summary_df.to_csv(full_summary_path, index=False)
            st.info(f"💾 Saved: {full_summary_path}")
            
            # Raw predictions (for appendix)
            raw_pred_path = os.path.join(summary_dir, "tvpvar_raw_predictions.csv")
            results_df.to_csv(raw_pred_path, index=False)
            st.info(f"💾 Saved: {raw_pred_path}")
            
            # Residuals only
            residuals_df = results_df[['date', 'error']].copy()
            residuals_df.columns = ['date', 'residual']
            residuals_path = os.path.join(summary_dir, "tvpvar_residuals.csv")
            residuals_df.to_csv(residuals_path, index=False)
            st.info(f"💾 Saved: {residuals_path}")
            
            st.success("✅ **TVP-VAR modeling completed successfully!**")
            st.balloons()
        
        # Final summary display
        st.markdown("---")
        st.subheader("📊 Final Summary")
        
        tab1, tab2, tab3, tab4 = st.tabs([
            "Model Summary",
            "Error Analysis",
            "Predictions Preview",
            "Download Files"
        ])
        
        with tab1:
            st.write("**Model Configuration:**")
            config_df = pd.DataFrame({
                'Parameter': ['Target Variable', 'Number of Variables', 'Optimal Lag', 
                             'Training Samples', 'Test Samples', 'Forecasts Generated'],
                'Value': [target_var, len(available_vars), int(optimal_lag),
                         len(train_data), len(test_data), len(results_df)]
            })
            st.dataframe(config_df, use_container_width=True)
            
            st.write("**Variables Used:**")
            st.write(", ".join(available_vars))
        
        with tab2:
            st.write("**Error Metrics:**")
            st.dataframe(error_stats_df, use_container_width=True)
            
            st.write("**Directional Accuracy:**")
            st.dataframe(dir_acc_df, use_container_width=True)
            
            st.write("**Full Summary:**")
            st.dataframe(full_summary_df, use_container_width=True)
        
        with tab3:
            st.write("**First 20 Predictions:**")
            st.dataframe(results_df.head(20), use_container_width=True)
            
            st.write("**Last 20 Predictions:**")
            st.dataframe(results_df.tail(20), use_container_width=True)
        
        with tab4:
            st.write("**Generated Files:**")
            
            files_info = [
                ("result/tvpvar/tvpvar_predictions.csv", "All predictions with errors"),
                ("result/tvpvar/tvpvar_error_stats.csv", "Error statistics summary"),
                ("result/tvpvar/tvpvar_directional_accuracy.csv", "Directional accuracy metric"),
                ("result_summary/tvpvar_lag_selection.csv", "AIC lag selection results"),
                ("result_summary/tvpvar_actual_vs_pred.png", "Actual vs Forecast plot (300 DPI)"),
                ("result_summary/tvpvar_residual_hist.png", "Residual histogram (300 DPI)"),
                ("result_summary/tvpvar_rolling_mae.png", "Rolling MAE plot (300 DPI)"),
                ("result_summary/tvpvar_full_summary.csv", "Complete summary for manuscript"),
                ("result_summary/tvpvar_raw_predictions.csv", "Raw predictions for appendix"),
                ("result_summary/tvpvar_residuals.csv", "Residuals time-series")
            ]
            
            files_df = pd.DataFrame(files_info, columns=['File Path', 'Description'])
            st.dataframe(files_df, use_container_width=True)
            
            st.success(f"✅ All {len(files_info)} files generated successfully!")
            
            st.info("""
            **For MDPI Manuscript:**
            - Use PNG files from `result_summary/` for figures
            - Use `tvpvar_full_summary.csv` for results table
            - Use `tvpvar_raw_predictions.csv` for supplementary materials
            """)
