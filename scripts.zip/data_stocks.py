def data_stocks():
    tickers = [
        # --- Core REIT Asset ---
        {"label": "Vanguard Real Estate ETF (REIT)", "ticker": "VNQ", "asset_class": "reit"},

        # --- US Rates (Most Important Driver for REIT) ---
        {"label": "US 10-Year Treasury Yield", "ticker": "^TNX", "asset_class": "rate"},
        {"label": "iShares 7–10 Year Treasury Bond ETF", "ticker": "IEF", "asset_class": "rate"},

        # --- US Equity Market Benchmark ---
        {"label": "S&P 500", "ticker": "^GSPC", "asset_class": "index"},

        # --- Global Indices (Optional) ---
        {"label": "FTSE 100", "ticker": "^FTSE", "asset_class": "index"},
        {"label": "Nikkei 225", "ticker": "^N225", "asset_class": "index"},
        {"label": "Hang Seng Index", "ticker": "^HSI", "asset_class": "index"},

        # --- Volatility / Risk Sentiment ---
        {"label": "CBOE Volatility Index", "ticker": "^VIX", "asset_class": "volatility_index"},

        # --- Credit Market Indicator (Very Useful for REIT) ---
        {"label": "High Yield Corporate Bond ETF", "ticker": "HYG", "asset_class": "credit"},

        # --- Optional Factors ---
        {"label": "Gold Futures", "ticker": "GC=F", "asset_class": "commodity"},
        {"label": "Crude Oil WTI", "ticker": "CL=F", "asset_class": "commodity"},
    ]


    return tickers
