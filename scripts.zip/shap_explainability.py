import streamlit as st
import os
import pandas as pd
import numpy as np
import pickle
import json
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow import keras
import shap
import warnings
warnings.filterwarnings('ignore')

def create_sequences(data, target_col_idx, window_size):
    """
    Create sequences for LSTM
    
    Args:
        data: numpy array of features
        target_col_idx: index of target column
        window_size: number of time steps to look back
    
    Returns:
        X: sequences of shape (samples, window_size, features)
        y: target values
    """
    X, y = [], []
    
    for i in range(window_size, len(data)):
        X.append(data[i-window_size:i])
        y.append(data[i, target_col_idx])
    
    return np.array(X), np.array(y)


def show_shap_explainability(result_dir="result", summary_dir="result_summary"):
    """
    SHAP Explainability Module for LSTM Models
    
    Analyzes feature importance and time-varying effects using SHAP values
    """
    
    st.title("🔍 SHAP Explainability Analysis")
    st.markdown("""
    ### Interpretable AI for LSTM Forecasting
    
    This module uses **SHAP (SHapley Additive exPlanations)** with KernelExplainer to explain:
    - **Global feature importance**: Which factors matter most?
    - **Feature interactions**: How do features interact?
    - **Time-varying effects**: How does importance change over time?
    - **Regime analysis**: Different behavior in high vs low volatility?
    
    *Note: Using KernelSHAP for maximum compatibility (model-agnostic, works with any TensorFlow version)*
    
    ⚠️ **Expected time**: 10-20 minutes (KernelSHAP is thorough but slower than gradient-based methods)
    """)
    
    # Ensure directories exist
    shap_dir = os.path.join(result_dir, "shap")
    os.makedirs(shap_dir, exist_ok=True)
    os.makedirs(summary_dir, exist_ok=True)
    
    # Check for required files
    data_prep_dir = os.path.join(result_dir, "data_prep")
    lstm_models_dir = os.path.join(result_dir, "lstm", "models")
    
    train_path = os.path.join(data_prep_dir, "train_scaled.csv")
    val_path = os.path.join(data_prep_dir, "val_scaled.csv")
    test_path = os.path.join(data_prep_dir, "test_scaled.csv")
    scaler_path = os.path.join(data_prep_dir, "scaler.pkl")
    model_path = os.path.join(lstm_models_dir, "LSTM_Base.h5")
    
    files_exist = all([
        os.path.exists(train_path),
        os.path.exists(test_path),
        os.path.exists(scaler_path),
        os.path.exists(model_path)
    ])
    
    if not files_exist:
        st.error("⚠️ Required files not found!")
        st.info("Please ensure you have completed:")
        st.markdown("""
        1. **Data Loading & Preprocessing** (for scaled data)
        2. **LSTM Modeling** (for trained LSTM_Base model)
        
        Required files:
        - `result/data_prep/train_scaled.csv`
        - `result/data_prep/test_scaled.csv`
        - `result/data_prep/scaler.pkl`
        - `result/lstm/models/LSTM_Base.h5`
        """)
        return
    
    st.success("✓ All required files found")
    
    # Configuration
    st.subheader("⚙️ Configuration")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        model_name = st.selectbox("Model to Analyze", 
                                   ["LSTM_Base", "LSTM_A", "LSTM_B"],
                                   index=0)
        window_size_map = {"LSTM_A": 8, "LSTM_Base": 12, "LSTM_B": 20}
        window_size = window_size_map[model_name]
        st.info(f"Window size: {window_size}")
    
    with col2:
        target_var = st.selectbox("Target Variable", 
                                   ["log_return_VNQ", "log_return_SPY"],
                                   index=0)
    
    with col3:
        background_samples = st.slider("Background Samples", 
                                       100, 1000, 500, 50)
        st.info("For SHAP computation")
    
    # Advanced options
    with st.expander("🔧 Advanced Options"):
        enable_regime = st.checkbox("Enable Regime Analysis", value=True)
        regime_threshold = st.slider("VIX High Volatility Threshold (Percentile)", 
                                     50, 90, 75, 5)
    
    st.markdown("---")
    
    # Main execution button
    if st.button("🚀 Run SHAP Analysis", type="primary", use_container_width=True):
        
        with st.spinner("Loading data and model..."):
            
            st.subheader("Step 1: Loading Data and Model")
            
            try:
                # Load data
                train_df = pd.read_csv(train_path)
                test_df = pd.read_csv(test_path)
                
                with open(scaler_path, 'rb') as f:
                    scaler = pickle.load(f)
                
                # Load model
                model_file = os.path.join(lstm_models_dir, f"{model_name}.h5")
                if not os.path.exists(model_file):
                    st.error(f"Model {model_name} not found. Please train it first.")
                    return
                
                # Load model with custom objects to handle metric compatibility
                try:
                    model = keras.models.load_model(model_file, compile=False)
                    # Recompile with standard metrics
                    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
                except Exception as e:
                    st.error(f"Error loading model: {str(e)}")
                    st.info("Try retraining the LSTM model with the latest code.")
                    return
                
                st.success(f"✓ Loaded: Train={len(train_df)}, Test={len(test_df)}")
                st.success(f"✓ Loaded model: {model_name}")
                
                # Get feature columns
                feature_cols = [col for col in train_df.columns if col != 'date']
                
                if target_var not in feature_cols:
                    st.error(f"Target variable '{target_var}' not found!")
                    return
                
                target_idx = feature_cols.index(target_var)
                n_features = len(feature_cols)
                
                st.info(f"📊 Features: {n_features}, Target: {target_var} (index {target_idx})")
                st.write(f"**Feature list**: {', '.join(feature_cols)}")
                
                # Extract dates
                if 'date' in test_df.columns:
                    test_dates = pd.to_datetime(test_df['date'])
                else:
                    test_dates = None
                
                # Convert to numpy
                train_data = train_df[feature_cols].values
                test_data = test_df[feature_cols].values
                
            except Exception as e:
                st.error(f"Error loading data: {str(e)}")
                return
        
        with st.spinner("Preparing sequences..."):
            
            st.subheader("Step 2: Preparing Sequences")
            
            # Create sequences
            X_train, y_train = create_sequences(train_data, target_idx, window_size)
            X_test, y_test = create_sequences(test_data, target_idx, window_size)
            
            st.write(f"**Train sequences**: X={X_train.shape}, y={y_train.shape}")
            st.write(f"**Test sequences**: X={X_test.shape}, y={y_test.shape}")
            
            # Sample background data
            n_background = min(background_samples, len(X_train))
            background_indices = np.random.choice(len(X_train), n_background, replace=False)
            X_background = X_train[background_indices]
            
            st.info(f"📊 Background samples: {n_background}")
            
            # Adjust test dates for window
            if test_dates is not None:
                test_dates_aligned = test_dates.iloc[window_size:].reset_index(drop=True)
            else:
                test_dates_aligned = None
        
        with st.spinner("Computing SHAP values (this may take several minutes)..."):
            
            st.subheader("Step 3: Computing SHAP Values")
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                # Create SHAP explainer
                status_text.text("Creating SHAP explainer...")
                progress_bar.progress(10)
                
                # Use KernelExplainer for maximum compatibility
                # This is model-agnostic and works with any TensorFlow version
                
                # Create prediction function that flattens input/output for KernelSHAP
                def predict_fn(x):
                    # x shape: (n_samples, window_size * n_features) - flattened
                    # Reshape to LSTM input: (n_samples, window_size, n_features)
                    x_reshaped = x.reshape(-1, window_size, n_features)
                    predictions = model.predict(x_reshaped, verbose=0)
                    return predictions.flatten()
                
                # Flatten background data for KernelSHAP
                X_background_flat = X_background.reshape(len(X_background), -1)
                
                # Create explainer
                explainer = shap.KernelExplainer(predict_fn, X_background_flat)
                
                status_text.text("Computing SHAP values for test set...")
                st.info("⏳ Using KernelSHAP for maximum compatibility. This may take 10-20 minutes...")
                progress_bar.progress(30)
                
                # Compute SHAP values in smaller batches
                # KernelSHAP is slower, so use smaller batches
                batch_size = 10
                shap_values_list = []
                
                for i in range(0, len(X_test), batch_size):
                    batch_end = min(i + batch_size, len(X_test))
                    batch = X_test[i:batch_end]
                    
                    # Flatten batch for KernelSHAP
                    batch_flat = batch.reshape(len(batch), -1)
                    
                    # Compute SHAP values
                    batch_shap = explainer.shap_values(batch_flat, nsamples=100)
                    
                    # Reshape back to (batch_size, window_size, n_features)
                    batch_shap_reshaped = batch_shap.reshape(len(batch), window_size, n_features)
                    
                    shap_values_list.append(batch_shap_reshaped)
                    
                    # Update progress
                    progress = 30 + int(40 * (batch_end / len(X_test)))
                    progress_bar.progress(progress)
                    status_text.text(f"Computing SHAP values... {batch_end}/{len(X_test)} (KernelSHAP)")
                
                # Concatenate all batches
                shap_values = np.concatenate(shap_values_list, axis=0)
                
                progress_bar.progress(70)
                status_text.text("Saving SHAP values...")
                
                # Save SHAP values
                shap_values_path = os.path.join(shap_dir, f"shap_values_{model_name}.npy")
                np.save(shap_values_path, shap_values)
                
                X_test_path = os.path.join(shap_dir, f"X_test_{model_name}.npy")
                np.save(X_test_path, X_test)
                
                # Save metadata
                metadata = {
                    'model': model_name,
                    'window_size': window_size,
                    'target_variable': target_var,
                    'features': feature_cols,
                    'n_test_samples': len(X_test),
                    'n_background_samples': n_background,
                    'shap_values_shape': shap_values.shape
                }
                
                metadata_path = os.path.join(shap_dir, f"shap_metadata_{model_name}.json")
                with open(metadata_path, 'w') as f:
                    json.dump(metadata, f, indent=2)
                
                progress_bar.progress(100)
                status_text.text("✓ SHAP computation completed!")
                
                st.success(f"✓ SHAP values computed: shape={shap_values.shape}")
                st.info(f"💾 Saved: {shap_values_path}")
                st.info(f"💾 Saved: {X_test_path}")
                st.info(f"💾 Saved: {metadata_path}")
                
            except Exception as e:
                st.error(f"Error computing SHAP values: {str(e)}")
                st.info("Try reducing background samples or using a smaller test set")
                return
        
        with st.spinner("Analyzing global feature importance..."):
            
            st.subheader("Step 4: Global Feature Importance")
            
            # Average SHAP values across time steps and samples
            # Shape: (n_samples, window_size, n_features)
            shap_values_mean = np.mean(np.abs(shap_values), axis=(0, 1))
            
            # Create importance dataframe
            importance_df = pd.DataFrame({
                'feature_name': feature_cols,
                'mean_abs_shap': shap_values_mean
            })
            
            importance_df = importance_df.sort_values('mean_abs_shap', ascending=False)
            importance_df['rank'] = range(1, len(importance_df) + 1)
            
            # Save
            importance_path = os.path.join(shap_dir, "shap_global_importance.csv")
            importance_df.to_csv(importance_path, index=False)
            
            importance_summary_path = os.path.join(summary_dir, "shap_global_importance.csv")
            importance_df.to_csv(importance_summary_path, index=False)
            
            st.success("✓ Global importance calculated")
            st.dataframe(importance_df, use_container_width=True)
            
            # Plot global importance
            fig_importance, ax = plt.subplots(figsize=(10, 6))
            
            colors = plt.cm.viridis(np.linspace(0.3, 0.9, len(importance_df)))
            bars = ax.barh(importance_df['feature_name'], 
                          importance_df['mean_abs_shap'],
                          color=colors)
            
            ax.set_xlabel('Mean |SHAP Value|', fontsize=12, fontweight='bold')
            ax.set_ylabel('Feature', fontsize=12, fontweight='bold')
            ax.set_title(f'{model_name}: Global Feature Importance', 
                        fontsize=14, fontweight='bold')
            ax.invert_yaxis()
            ax.grid(True, alpha=0.3, axis='x')
            plt.tight_layout()
            
            importance_fig_path = os.path.join(summary_dir, "shap_global_importance_bar.png")
            fig_importance.savefig(importance_fig_path, dpi=300, bbox_inches='tight')
            st.pyplot(fig_importance)
            plt.close()
            
            st.info(f"💾 Saved: {importance_fig_path}")
        
        with st.spinner("Creating SHAP summary plot..."):
            
            st.subheader("Step 5: SHAP Summary (Beeswarm) Plot")
            
            # Reshape for summary plot
            # We need (n_samples, n_features)
            # Average across time dimension
            shap_values_2d = np.mean(shap_values, axis=1)
            X_test_2d = np.mean(X_test, axis=1)
            
            fig_summary = plt.figure(figsize=(10, 8))
            shap.summary_plot(shap_values_2d, X_test_2d, 
                            feature_names=feature_cols,
                            show=False, plot_size=(10, 8))
            plt.title(f'{model_name}: SHAP Summary Plot', 
                     fontsize=14, fontweight='bold', pad=20)
            plt.tight_layout()
            
            beeswarm_path = os.path.join(summary_dir, f"shap_beeswarm_{model_name}.png")
            plt.savefig(beeswarm_path, dpi=300, bbox_inches='tight')
            st.pyplot(fig_summary)
            plt.close()
            
            st.success(f"✓ Beeswarm plot created")
            st.info(f"💾 Saved: {beeswarm_path}")
        
        with st.spinner("Creating SHAP dependence plots..."):
            
            st.subheader("Step 6: SHAP Dependence Plots")
            
            # Get top features
            top_features = importance_df['feature_name'].head(4).tolist()
            
            for feature in top_features:
                if feature not in feature_cols:
                    continue
                
                feature_idx = feature_cols.index(feature)
                
                fig_dep, ax_dep = plt.subplots(figsize=(10, 6))
                
                # Get feature values and SHAP values
                feature_values = X_test_2d[:, feature_idx]
                feature_shap = shap_values_2d[:, feature_idx]
                
                scatter = ax_dep.scatter(feature_values, feature_shap, 
                                        alpha=0.5, s=20, c=feature_values,
                                        cmap='viridis')
                
                ax_dep.set_xlabel(f'{feature} Value', fontsize=12, fontweight='bold')
                ax_dep.set_ylabel(f'SHAP Value for {feature}', fontsize=12, fontweight='bold')
                ax_dep.set_title(f'{model_name}: SHAP Dependence - {feature}', 
                               fontsize=14, fontweight='bold')
                ax_dep.axhline(0, color='red', linestyle='--', linewidth=1, alpha=0.5)
                ax_dep.grid(True, alpha=0.3)
                
                plt.colorbar(scatter, ax=ax_dep, label=f'{feature} Value')
                plt.tight_layout()
                
                # Clean feature name for filename
                feature_clean = feature.replace('log_return_', '').replace('yield_change_', '')
                dep_path = os.path.join(summary_dir, f"shap_dependence_{feature_clean}.png")
                fig_dep.savefig(dep_path, dpi=300, bbox_inches='tight')
                st.pyplot(fig_dep)
                plt.close()
                
                st.info(f"💾 Saved: {dep_path}")
            
            st.success(f"✓ Created {len(top_features)} dependence plots")
        
        with st.spinner("Analyzing time-varying SHAP values..."):
            
            st.subheader("Step 7: Time-Varying Feature Importance")
            
            # Average SHAP across time dimension for each sample
            shap_time_series = np.mean(shap_values, axis=1)
            
            # Create time series dataframe
            time_series_data = {'date': test_dates_aligned if test_dates_aligned is not None else range(len(shap_time_series))}
            
            for i, feature in enumerate(feature_cols):
                time_series_data[f'shap_{feature}'] = shap_time_series[:, i]
            
            time_series_df = pd.DataFrame(time_series_data)
            
            # Save
            time_series_path = os.path.join(shap_dir, "shap_time_series_values.csv")
            time_series_df.to_csv(time_series_path, index=False)
            
            st.success("✓ Time series SHAP values saved")
            st.info(f"💾 Saved: {time_series_path}")
            
            # Plot time series for top features
            top_features_ts = importance_df['feature_name'].head(3).tolist()
            
            for feature in top_features_ts:
                if feature not in feature_cols:
                    continue
                
                fig_ts, ax_ts = plt.subplots(figsize=(12, 6))
                
                shap_col = f'shap_{feature}'
                ax_ts.plot(time_series_df['date'], time_series_df[shap_col], 
                          linewidth=2, color='darkblue')
                ax_ts.axhline(0, color='red', linestyle='--', linewidth=1, alpha=0.5)
                
                ax_ts.set_xlabel('Date', fontsize=12, fontweight='bold')
                ax_ts.set_ylabel(f'SHAP Value', fontsize=12, fontweight='bold')
                ax_ts.set_title(f'{model_name}: Time-Varying SHAP - {feature}', 
                              fontsize=14, fontweight='bold')
                ax_ts.grid(True, alpha=0.3)
                
                if test_dates_aligned is not None:
                    plt.xticks(rotation=45)
                
                plt.tight_layout()
                
                feature_clean = feature.replace('log_return_', '').replace('yield_change_', '')
                ts_path = os.path.join(summary_dir, f"shap_time_series_{feature_clean}.png")
                fig_ts.savefig(ts_path, dpi=300, bbox_inches='tight')
                st.pyplot(fig_ts)
                plt.close()
                
                st.info(f"💾 Saved: {ts_path}")
            
            st.success(f"✓ Created {len(top_features_ts)} time-series plots")
        
        # Regime analysis
        if enable_regime:
            with st.spinner("Performing regime-based analysis..."):
                
                st.subheader("Step 8: Regime-Based SHAP Analysis")
                
                # Determine regime based on VIX
                vix_col = None
                for col in feature_cols:
                    if 'VIX' in col.upper():
                        vix_col = col
                        break
                
                if vix_col is None:
                    st.warning("⚠️ VIX column not found. Skipping regime analysis.")
                else:
                    vix_idx = feature_cols.index(vix_col)
                    vix_values = X_test_2d[:, vix_idx]
                    
                    # Define regime threshold
                    vix_threshold = np.percentile(vix_values, regime_threshold)
                    
                    high_vol_mask = vix_values > vix_threshold
                    low_vol_mask = ~high_vol_mask
                    
                    st.write(f"**VIX threshold (P{regime_threshold})**: {vix_threshold:.4f}")
                    st.write(f"**Low volatility samples**: {low_vol_mask.sum()}")
                    st.write(f"**High volatility samples**: {high_vol_mask.sum()}")
                    
                    # Calculate regime-specific importance
                    regime_data = []
                    
                    for regime, mask in [('low_vol', low_vol_mask), ('high_vol', high_vol_mask)]:
                        if mask.sum() == 0:
                            continue
                        
                        regime_shap = shap_values_2d[mask]
                        regime_importance = np.mean(np.abs(regime_shap), axis=0)
                        
                        for i, feature in enumerate(feature_cols):
                            regime_data.append({
                                'regime': regime,
                                'feature_name': feature,
                                'mean_abs_shap': regime_importance[i]
                            })
                    
                    regime_df = pd.DataFrame(regime_data)
                    
                    # Save
                    regime_path = os.path.join(shap_dir, "shap_regime_importance.csv")
                    regime_df.to_csv(regime_path, index=False)
                    
                    regime_summary_path = os.path.join(summary_dir, "shap_regime_importance.csv")
                    regime_df.to_csv(regime_summary_path, index=False)
                    
                    st.success("✓ Regime analysis completed")
                    st.dataframe(regime_df, use_container_width=True)
                    
                    # Plot regime comparison
                    fig_regime, ax_regime = plt.subplots(figsize=(12, 8))
                    
                    # Pivot for grouped bar chart
                    regime_pivot = regime_df.pivot(index='feature_name', 
                                                   columns='regime', 
                                                   values='mean_abs_shap')
                    
                    regime_pivot.plot(kind='barh', ax=ax_regime, 
                                     color=['skyblue', 'coral'])
                    
                    ax_regime.set_xlabel('Mean |SHAP Value|', fontsize=12, fontweight='bold')
                    ax_regime.set_ylabel('Feature', fontsize=12, fontweight='bold')
                    ax_regime.set_title(f'{model_name}: Feature Importance by Volatility Regime', 
                                       fontsize=14, fontweight='bold')
                    ax_regime.legend(title='Regime', fontsize=11)
                    ax_regime.grid(True, alpha=0.3, axis='x')
                    plt.tight_layout()
                    
                    regime_fig_path = os.path.join(summary_dir, "shap_regime_importance_bar.png")
                    fig_regime.savefig(regime_fig_path, dpi=300, bbox_inches='tight')
                    st.pyplot(fig_regime)
                    plt.close()
                    
                    st.info(f"💾 Saved: {regime_fig_path}")
        
        # Final summary
        st.markdown("---")
        st.success("✅ **SHAP Analysis Completed Successfully!**")
        st.balloons()
        
        st.subheader("📁 Generated Files Summary")
        
        tab1, tab2, tab3, tab4 = st.tabs([
            "SHAP Data",
            "Global Analysis",
            "Feature Analysis",
            "Time & Regime"
        ])
        
        with tab1:
            st.write("**SHAP Values & Metadata:**")
            st.write(f"✓ `result/shap/shap_values_{model_name}.npy`")
            st.write(f"✓ `result/shap/X_test_{model_name}.npy`")
            st.write(f"✓ `result/shap/shap_metadata_{model_name}.json`")
        
        with tab2:
            st.write("**Global Feature Importance:**")
            st.write(f"✓ `result/shap/shap_global_importance.csv`")
            st.write(f"✓ `result_summary/shap_global_importance.csv`")
            st.write(f"✓ `result_summary/shap_global_importance_bar.png`")
            st.write(f"✓ `result_summary/shap_beeswarm_{model_name}.png`")
        
        with tab3:
            st.write("**Dependence Plots:**")
            for feature in top_features:
                feature_clean = feature.replace('log_return_', '').replace('yield_change_', '')
                st.write(f"✓ `result_summary/shap_dependence_{feature_clean}.png`")
        
        with tab4:
            st.write("**Time-Series Analysis:**")
            st.write(f"✓ `result/shap/shap_time_series_values.csv`")
            for feature in top_features_ts:
                feature_clean = feature.replace('log_return_', '').replace('yield_change_', '')
                st.write(f"✓ `result_summary/shap_time_series_{feature_clean}.png`")
            
            if enable_regime and vix_col:
                st.write("\n**Regime Analysis:**")
                st.write(f"✓ `result/shap/shap_regime_importance.csv`")
                st.write(f"✓ `result_summary/shap_regime_importance.csv`")
                st.write(f"✓ `result_summary/shap_regime_importance_bar.png`")
        
        st.info("""
        **For MDPI Manuscript:**
        - Use global importance bar for main results
        - Use beeswarm plot for feature interactions
        - Use dependence plots for individual feature analysis
        - Use time-series plots for dynamic sensitivity discussion
        - Use regime analysis for volatility-dependent behavior
        """)
        
        # Key insights
        st.markdown("---")
        st.subheader("🔑 Key Insights")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Most Important Feature", 
                     importance_df.iloc[0]['feature_name'],
                     f"SHAP: {importance_df.iloc[0]['mean_abs_shap']:.6f}")
            
            st.metric("2nd Most Important", 
                     importance_df.iloc[1]['feature_name'],
                     f"SHAP: {importance_df.iloc[1]['mean_abs_shap']:.6f}")
        
        with col2:
            st.metric("3rd Most Important", 
                     importance_df.iloc[2]['feature_name'],
                     f"SHAP: {importance_df.iloc[2]['mean_abs_shap']:.6f}")
            
            st.metric("Total Features Analyzed", 
                     len(feature_cols))
        
        st.markdown("""
        **Interpretation Guide:**
        - **Higher SHAP value** = More important for prediction
        - **Positive SHAP** = Feature pushes prediction higher
        - **Negative SHAP** = Feature pushes prediction lower
        - **Regime differences** = Feature importance varies with market conditions
        """)
