import streamlit as st
import os
import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
import warnings
warnings.filterwarnings('ignore')

def create_sequences(data, target_col_idx, window_size):
    """
    Create sequences for LSTM training
    
    Args:
        data: numpy array of features
        target_col_idx: index of target column
        window_size: number of time steps to look back
    
    Returns:
        X: sequences of shape (samples, window_size, features)
        y: target values
    """
    X, y = [], []
    
    for i in range(window_size, len(data)):
        X.append(data[i-window_size:i])
        y.append(data[i, target_col_idx])
    
    return np.array(X), np.array(y)


def build_lstm_model(window_size, n_features, layers, learning_rate):
    """
    Build LSTM model with specified architecture
    
    Args:
        window_size: sequence length
        n_features: number of input features
        layers: list of units per LSTM layer
        learning_rate: learning rate for Adam optimizer
    
    Returns:
        compiled Keras model
    """
    model = Sequential()
    
    # First LSTM layer
    if len(layers) == 1:
        model.add(LSTM(layers[0], input_shape=(window_size, n_features)))
    else:
        model.add(LSTM(layers[0], return_sequences=True, input_shape=(window_size, n_features)))
        model.add(Dropout(0.2))
        
        # Middle LSTM layers
        for units in layers[1:-1]:
            model.add(LSTM(units, return_sequences=True))
            model.add(Dropout(0.2))
        
        # Last LSTM layer
        model.add(LSTM(layers[-1]))
        model.add(Dropout(0.2))
    
    # Output layer
    model.add(Dense(1))
    
    # Compile
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(optimizer=optimizer, loss='mse', metrics=['mae'])
    
    return model


def show_lstm_modeling(result_dir="result", summary_dir="result_summary"):
    """
    LSTM Modeling Module for REIT Forecasting
    
    Implements three LSTM configurations:
    - LSTM_A: Shallow (1 layer, window=8)
    - LSTM_Base: Baseline (2 layers, window=12)
    - LSTM_B: Deep (3 layers, window=20)
    """
    
    st.title("🧠 LSTM Modeling")
    st.markdown("""
    ### Long Short-Term Memory Networks for REIT Forecasting
    
    This module implements **three LSTM configurations** for comparison:
    - **LSTM_A**: Shallow model (1 layer, window=8)
    - **LSTM_Base**: Baseline model (2 layers, window=12)
    - **LSTM_B**: Deep model (3 layers, window=20)
    
    Each model is trained with early stopping and learning rate reduction.
    """)
    
    # Ensure directories exist
    lstm_dir = os.path.join(result_dir, "lstm")
    models_dir = os.path.join(lstm_dir, "models")
    pred_dir = os.path.join(lstm_dir, "predictions")
    metrics_dir = os.path.join(lstm_dir, "metrics")
    logs_dir = os.path.join(lstm_dir, "logs")
    
    for d in [models_dir, pred_dir, metrics_dir, logs_dir]:
        os.makedirs(d, exist_ok=True)
    
    os.makedirs(summary_dir, exist_ok=True)
    
    # Check for preprocessed data
    data_prep_dir = os.path.join(result_dir, "data_prep")
    train_path = os.path.join(data_prep_dir, "train_scaled.csv")
    val_path = os.path.join(data_prep_dir, "val_scaled.csv")
    test_path = os.path.join(data_prep_dir, "test_scaled.csv")
    scaler_path = os.path.join(data_prep_dir, "scaler.pkl")
    
    files_exist = all([
        os.path.exists(train_path),
        os.path.exists(val_path),
        os.path.exists(test_path),
        os.path.exists(scaler_path)
    ])
    
    if not files_exist:
        st.error("⚠️ Preprocessed scaled data not found!")
        st.info("Please run **Data Loading & Preprocessing** first to generate scaled data.")
        st.markdown("""
        Required files:
        - `result/data_prep/train_scaled.csv`
        - `result/data_prep/val_scaled.csv`
        - `result/data_prep/test_scaled.csv`
        - `result/data_prep/scaler.pkl`
        """)
        return
    
    st.success("✓ Preprocessed scaled data found")
    
    # Model configurations
    st.subheader("⚙️ Model Configurations")
    
    model_configs = {
        'LSTM_A': {
            'layers': [32],
            'window_size': 8,
            'learning_rate': 0.001,
            'description': 'Shallow (1 layer)'
        },
        'LSTM_Base': {
            'layers': [64, 32],
            'window_size': 12,
            'learning_rate': 0.001,
            'description': 'Baseline (2 layers)'
        },
        'LSTM_B': {
            'layers': [128, 64, 32],
            'window_size': 20,
            'learning_rate': 0.0005,
            'description': 'Deep (3 layers)'
        }
    }
    
    # Display configurations
    config_data = []
    for name, config in model_configs.items():
        config_data.append({
            'Model': name,
            'Layers': str(config['layers']),
            'Window Size': config['window_size'],
            'Learning Rate': config['learning_rate'],
            'Description': config['description']
        })
    
    config_df = pd.DataFrame(config_data)
    st.dataframe(config_df, use_container_width=True)
    
    st.markdown("---")
    
    # Training parameters
    st.subheader("🎯 Training Parameters")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.write("**Optimizer:** Adam")
        st.write("**Loss:** MSE")
        st.write("**Batch Size:** 32")
    with col2:
        st.write("**Max Epochs:** 150")
        st.write("**Early Stopping:** 20")
        st.write("**LR Patience:** 10")
    with col3:
        target_var = st.selectbox("Target Variable", 
                                   ["log_return_VNQ", "log_return_SPY"],
                                   index=0)
    
    st.markdown("---")
    
    # Main execution button
    if st.button("🚀 Run LSTM Models", type="primary", use_container_width=True):
        
        all_results = {}
        
        with st.spinner("Loading and preparing data..."):
            
            # Load data
            st.subheader("Step 1: Loading Data")
            
            try:
                train_df = pd.read_csv(train_path)
                val_df = pd.read_csv(val_path)
                test_df = pd.read_csv(test_path)
                
                with open(scaler_path, 'rb') as f:
                    scaler = pickle.load(f)
                
                st.success(f"✓ Loaded: Train={len(train_df)}, Val={len(val_df)}, Test={len(test_df)}")
                
                # Get feature columns (exclude date if present)
                feature_cols = [col for col in train_df.columns if col != 'date']
                
                # Find target column index
                if target_var not in feature_cols:
                    st.error(f"Target variable '{target_var}' not found in data!")
                    return
                
                target_idx = feature_cols.index(target_var)
                n_features = len(feature_cols)
                
                st.info(f"📊 Features: {n_features}, Target: {target_var} (index {target_idx})")
                
                # Extract dates for later use
                if 'date' in train_df.columns:
                    train_dates = pd.to_datetime(train_df['date'])
                    val_dates = pd.to_datetime(val_df['date'])
                    test_dates = pd.to_datetime(test_df['date'])
                else:
                    train_dates = None
                    val_dates = None
                    test_dates = None
                
                # Convert to numpy arrays
                train_data = train_df[feature_cols].values
                val_data = val_df[feature_cols].values
                test_data = test_df[feature_cols].values
                
            except Exception as e:
                st.error(f"Error loading data: {str(e)}")
                return
        
        # Train each model
        for model_name, config in model_configs.items():
            
            st.markdown("---")
            st.subheader(f"Training {model_name}")
            
            window_size = config['window_size']
            layers = config['layers']
            learning_rate = config['learning_rate']
            
            with st.spinner(f"Preparing sequences for {model_name}..."):
                
                # Create sequences
                X_train, y_train = create_sequences(train_data, target_idx, window_size)
                X_val, y_val = create_sequences(val_data, target_idx, window_size)
                X_test, y_test = create_sequences(test_data, target_idx, window_size)
                
                st.write(f"**Sequences created:**")
                st.write(f"- Train: X={X_train.shape}, y={y_train.shape}")
                st.write(f"- Val: X={X_val.shape}, y={y_val.shape}")
                st.write(f"- Test: X={X_test.shape}, y={y_test.shape}")
            
            with st.spinner(f"Building {model_name} architecture..."):
                
                # Build model
                model = build_lstm_model(window_size, n_features, layers, learning_rate)
                
                # Display model summary
                st.write("**Model Architecture:**")
                
                # Capture model summary
                summary_lines = []
                model.summary(print_fn=lambda x: summary_lines.append(x))
                st.text('\n'.join(summary_lines[:15]))  # Show first 15 lines
                
                total_params = model.count_params()
                st.info(f"📊 Total parameters: {total_params:,}")
            
            with st.spinner(f"Training {model_name}..."):
                
                # Callbacks
                early_stop = EarlyStopping(
                    monitor='val_loss',
                    patience=20,
                    restore_best_weights=True,
                    verbose=0
                )
                
                reduce_lr = ReduceLROnPlateau(
                    monitor='val_loss',
                    factor=0.5,
                    patience=10,
                    min_lr=1e-7,
                    verbose=0
                )
                
                # Train
                history = model.fit(
                    X_train, y_train,
                    validation_data=(X_val, y_val),
                    epochs=150,
                    batch_size=32,
                    callbacks=[early_stop, reduce_lr],
                    verbose=0
                )
                
                epochs_trained = len(history.history['loss'])
                final_train_loss = history.history['loss'][-1]
                final_val_loss = history.history['val_loss'][-1]
                
                st.success(f"✓ Training completed in {epochs_trained} epochs")
                st.write(f"- Final train loss: {final_train_loss:.6f}")
                st.write(f"- Final val loss: {final_val_loss:.6f}")
            
            with st.spinner(f"Saving {model_name}..."):
                
                # Save model (use .keras format for better compatibility)
                model_path = os.path.join(models_dir, f"{model_name}.h5")
                try:
                    # Save with save_format to ensure compatibility
                    model.save(model_path, save_format='h5')
                except Exception as e:
                    st.warning(f"Note: Model saved with default format. May need recompilation when loading.")
                    model.save(model_path)
                st.info(f"💾 Saved: {model_path}")
                
                # Save training log
                log_df = pd.DataFrame({
                    'epoch': range(1, epochs_trained + 1),
                    'train_loss': history.history['loss'],
                    'val_loss': history.history['val_loss'],
                    'train_mae': history.history['mae'],
                    'val_mae': history.history['val_mae']
                })
                
                log_path = os.path.join(logs_dir, f"{model_name}_training_log.csv")
                log_df.to_csv(log_path, index=False)
                st.info(f"💾 Saved: {log_path}")
            
            with st.spinner(f"Generating forecasts for {model_name}..."):
                
                # Predict on test set
                y_pred_scaled = model.predict(X_test, verbose=0).flatten()
                
                # Inverse transform
                # Create dummy array with all features
                dummy_pred = np.zeros((len(y_pred_scaled), n_features))
                dummy_pred[:, target_idx] = y_pred_scaled
                
                dummy_actual = np.zeros((len(y_test), n_features))
                dummy_actual[:, target_idx] = y_test
                
                # Inverse transform
                pred_original = scaler.inverse_transform(dummy_pred)[:, target_idx]
                actual_original = scaler.inverse_transform(dummy_actual)[:, target_idx]
                
                # Calculate errors
                errors = actual_original - pred_original
                abs_errors = np.abs(errors)
                sq_errors = errors ** 2
                
                # Get corresponding dates
                if test_dates is not None:
                    pred_dates = test_dates.iloc[window_size:].reset_index(drop=True)
                else:
                    pred_dates = range(len(pred_original))
                
                # Create predictions dataframe
                pred_df = pd.DataFrame({
                    'date': pred_dates,
                    'actual': actual_original,
                    'prediction': pred_original,
                    'error': errors,
                    'abs_error': abs_errors,
                    'sq_error': sq_errors
                })
                
                # Save predictions
                pred_path = os.path.join(pred_dir, f"{model_name}_pred.csv")
                pred_df.to_csv(pred_path, index=False)
                st.info(f"💾 Saved: {pred_path}")
                
                st.success(f"✓ Generated {len(pred_df)} forecasts")
            
            with st.spinner(f"Calculating metrics for {model_name}..."):
                
                # Calculate metrics
                rmse = np.sqrt(np.mean(sq_errors))
                mae = np.mean(abs_errors)
                mean_error = np.mean(errors)
                std_error = np.std(errors)
                max_error = np.max(errors)
                min_error = np.min(errors)
                
                # Directional accuracy
                actual_direction = np.sign(actual_original)
                pred_direction = np.sign(pred_original)
                direction_match = (actual_direction == pred_direction).astype(int)
                directional_accuracy = np.mean(direction_match)
                
                # Create metrics dataframe
                metrics_df = pd.DataFrame({
                    'metric': ['rmse', 'mae', 'mean_error', 'std_error', 
                              'max_error', 'min_error', 'directional_accuracy'],
                    'value': [rmse, mae, mean_error, std_error, 
                             max_error, min_error, directional_accuracy]
                })
                
                # Save metrics
                metrics_path = os.path.join(metrics_dir, f"{model_name}_metrics.csv")
                metrics_df.to_csv(metrics_path, index=False)
                st.info(f"💾 Saved: {metrics_path}")
                
                # Display metrics
                col1, col2, col3, col4 = st.columns(4)
                col1.metric("RMSE", f"{rmse:.6f}")
                col2.metric("MAE", f"{mae:.6f}")
                col3.metric("Mean Error", f"{mean_error:.6f}")
                col4.metric("Dir. Accuracy", f"{directional_accuracy:.2%}")
            
            with st.spinner(f"Generating figures for {model_name}..."):
                
                # Set style
                plt.style.use('seaborn-v0_8-darkgrid')
                
                # Figure 1: Loss curve
                fig_loss, ax_loss = plt.subplots(figsize=(10, 6))
                ax_loss.plot(log_df['epoch'], log_df['train_loss'], 
                            label='Train Loss', linewidth=2)
                ax_loss.plot(log_df['epoch'], log_df['val_loss'], 
                            label='Val Loss', linewidth=2)
                ax_loss.set_xlabel('Epoch', fontsize=12)
                ax_loss.set_ylabel('Loss (MSE)', fontsize=12)
                ax_loss.set_title(f'{model_name}: Training History', 
                                 fontsize=14, fontweight='bold')
                ax_loss.legend(fontsize=11)
                ax_loss.grid(True, alpha=0.3)
                plt.tight_layout()
                
                loss_path = os.path.join(summary_dir, f"lstm_{model_name.lower()}_loss_curve.png")
                fig_loss.savefig(loss_path, dpi=300, bbox_inches='tight')
                st.pyplot(fig_loss)
                plt.close()
                st.info(f"💾 Saved: {loss_path}")
                
                # Figure 2: Actual vs Prediction
                fig_pred, ax_pred = plt.subplots(figsize=(12, 6))
                ax_pred.plot(pred_df['date'], pred_df['actual'], 
                            label='Actual', linewidth=2, alpha=0.8)
                ax_pred.plot(pred_df['date'], pred_df['prediction'], 
                            label='Prediction', linewidth=2, alpha=0.8, linestyle='--')
                ax_pred.set_xlabel('Date', fontsize=12)
                ax_pred.set_ylabel(target_var, fontsize=12)
                ax_pred.set_title(f'{model_name}: Actual vs Prediction', 
                                 fontsize=14, fontweight='bold')
                ax_pred.legend(fontsize=11)
                ax_pred.grid(True, alpha=0.3)
                plt.xticks(rotation=45)
                plt.tight_layout()
                
                pred_fig_path = os.path.join(summary_dir, 
                                             f"lstm_{model_name.lower()}_actual_vs_pred.png")
                fig_pred.savefig(pred_fig_path, dpi=300, bbox_inches='tight')
                st.pyplot(fig_pred)
                plt.close()
                st.info(f"💾 Saved: {pred_fig_path}")
                
                # Figure 3: Residual histogram
                fig_hist, ax_hist = plt.subplots(figsize=(10, 6))
                ax_hist.hist(pred_df['error'], bins=30, edgecolor='black', alpha=0.7)
                ax_hist.axvline(0, color='red', linestyle='--', linewidth=2, 
                               label='Zero Error')
                ax_hist.set_xlabel('Residual (Error)', fontsize=12)
                ax_hist.set_ylabel('Frequency', fontsize=12)
                ax_hist.set_title(f'{model_name}: Residual Distribution', 
                                 fontsize=14, fontweight='bold')
                ax_hist.legend(fontsize=11)
                ax_hist.grid(True, alpha=0.3, axis='y')
                plt.tight_layout()
                
                hist_path = os.path.join(summary_dir, 
                                        f"lstm_{model_name.lower()}_residual_hist.png")
                fig_hist.savefig(hist_path, dpi=300, bbox_inches='tight')
                st.pyplot(fig_hist)
                plt.close()
                st.info(f"💾 Saved: {hist_path}")
                
                # Figure 4: Rolling MAE
                window = min(20, len(pred_df) // 5)
                pred_df['rolling_mae'] = pred_df['abs_error'].rolling(
                    window=window, min_periods=1).mean()
                
                fig_rolling, ax_rolling = plt.subplots(figsize=(12, 6))
                ax_rolling.plot(pred_df['date'], pred_df['rolling_mae'], 
                               linewidth=2, color='darkblue')
                ax_rolling.axhline(mae, color='red', linestyle='--', linewidth=2,
                                  label=f'Overall MAE={mae:.6f}')
                ax_rolling.set_xlabel('Date', fontsize=12)
                ax_rolling.set_ylabel(f'Rolling MAE (window={window})', fontsize=12)
                ax_rolling.set_title(f'{model_name}: Rolling Mean Absolute Error', 
                                    fontsize=14, fontweight='bold')
                ax_rolling.legend(fontsize=11)
                ax_rolling.grid(True, alpha=0.3)
                plt.xticks(rotation=45)
                plt.tight_layout()
                
                rolling_path = os.path.join(summary_dir, 
                                           f"lstm_{model_name.lower()}_rolling_mae.png")
                fig_rolling.savefig(rolling_path, dpi=300, bbox_inches='tight')
                st.pyplot(fig_rolling)
                plt.close()
                st.info(f"💾 Saved: {rolling_path}")
            
            # Store results for comparison
            all_results[model_name] = {
                'rmse': rmse,
                'mae': mae,
                'directional_accuracy': directional_accuracy,
                'epochs': epochs_trained,
                'params': total_params
            }
            
            st.success(f"✅ {model_name} completed successfully!")
        
        # Create comparative summary
        st.markdown("---")
        st.subheader("📊 Comparative Summary")
        
        with st.spinner("Creating comparative summary..."):
            
            # Create summary dataframe
            summary_data = []
            for model_name, results in all_results.items():
                summary_data.append({
                    'model': model_name,
                    'rmse': results['rmse'],
                    'mae': results['mae'],
                    'directional_accuracy': results['directional_accuracy'],
                    'epochs_trained': results['epochs'],
                    'total_parameters': results['params']
                })
            
            summary_df = pd.DataFrame(summary_data)
            
            # Save summary
            summary_path = os.path.join(summary_dir, "lstm_all_models_summary.csv")
            summary_df.to_csv(summary_path, index=False)
            st.info(f"💾 Saved: {summary_path}")
            
            # Display summary
            st.dataframe(summary_df, use_container_width=True)
            
            # Find best model
            best_model = summary_df.loc[summary_df['rmse'].idxmin(), 'model']
            st.success(f"🏆 Best model by RMSE: **{best_model}**")
        
        st.success("✅ **All LSTM models completed successfully!**")
        st.balloons()
        
        # Final summary
        st.markdown("---")
        st.subheader("📁 Generated Files Summary")
        
        tab1, tab2, tab3, tab4 = st.tabs([
            "Models & Logs",
            "Predictions",
            "Metrics",
            "Figures"
        ])
        
        with tab1:
            st.write("**Saved Models:**")
            for model_name in model_configs.keys():
                st.write(f"✓ `result/lstm/models/{model_name}.h5`")
            
            st.write("\n**Training Logs:**")
            for model_name in model_configs.keys():
                st.write(f"✓ `result/lstm/logs/{model_name}_training_log.csv`")
        
        with tab2:
            st.write("**Prediction Files:**")
            for model_name in model_configs.keys():
                st.write(f"✓ `result/lstm/predictions/{model_name}_pred.csv`")
        
        with tab3:
            st.write("**Metrics Files:**")
            for model_name in model_configs.keys():
                st.write(f"✓ `result/lstm/metrics/{model_name}_metrics.csv`")
            
            st.write("\n**Comparative Summary:**")
            st.write(f"✓ `result_summary/lstm_all_models_summary.csv`")
        
        with tab4:
            st.write("**Publication Figures (300 DPI):**")
            
            for model_name in model_configs.keys():
                model_lower = model_name.lower()
                st.write(f"\n**{model_name}:**")
                st.write(f"✓ `result_summary/lstm_{model_lower}_loss_curve.png`")
                st.write(f"✓ `result_summary/lstm_{model_lower}_actual_vs_pred.png`")
                st.write(f"✓ `result_summary/lstm_{model_lower}_residual_hist.png`")
                st.write(f"✓ `result_summary/lstm_{model_lower}_rolling_mae.png`")
            
            total_figures = len(model_configs) * 4
            st.success(f"✅ Total: {total_figures} figures generated")
        
        st.info("""
        **For MDPI Manuscript:**
        - Use figures from `result_summary/` for publication
        - Use `lstm_all_models_summary.csv` for comparison table
        - Use individual prediction files for supplementary materials
        """)
