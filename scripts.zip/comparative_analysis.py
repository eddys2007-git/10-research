import streamlit as st
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

def diebold_mariano_test(errors1, errors2):
    """
    Diebold-Mariano test for comparing forecast accuracy
    
    Args:
        errors1: forecast errors from model 1
        errors2: forecast errors from model 2
    
    Returns:
        dm_stat: DM test statistic
        p_value: two-tailed p-value
    """
    # Calculate loss differential (squared errors)
    d = (errors1 ** 2) - (errors2 ** 2)
    
    # Mean of loss differential
    d_mean = np.mean(d)
    
    # Calculate variance with Newey-West correction for autocorrelation
    n = len(d)
    
    # Simple variance (can be extended with HAC correction)
    d_var = np.var(d, ddof=1)
    
    # DM statistic
    dm_stat = d_mean / np.sqrt(d_var / n)
    
    # Two-tailed p-value
    p_value = 2 * (1 - stats.norm.cdf(abs(dm_stat)))
    
    return dm_stat, p_value


def directional_accuracy_test(actual, predicted):
    """
    Test if directional accuracy is significantly better than 0.5
    
    Args:
        actual: actual values
        predicted: predicted values
    
    Returns:
        da: directional accuracy
        z_score: z-statistic
        p_value: one-tailed p-value
        ci_lower, ci_upper: 95% confidence interval
    """
    # Calculate directional accuracy
    actual_direction = np.sign(np.diff(actual))
    pred_direction = np.sign(np.diff(predicted))
    
    correct = (actual_direction == pred_direction).sum()
    total = len(actual_direction)
    
    da = correct / total
    
    # Binomial test (H0: p = 0.5, H1: p > 0.5)
    # Under H0, follows normal distribution for large n
    p0 = 0.5
    z_score = (da - p0) / np.sqrt(p0 * (1 - p0) / total)
    
    # One-tailed p-value (testing if DA > 0.5)
    p_value = 1 - stats.norm.cdf(z_score)
    
    # 95% confidence interval
    ci_margin = 1.96 * np.sqrt(da * (1 - da) / total)
    ci_lower = da - ci_margin
    ci_upper = da + ci_margin
    
    return da, z_score, p_value, ci_lower, ci_upper


def calculate_metrics(actual, predicted):
    """
    Calculate comprehensive error metrics
    
    Args:
        actual: actual values
        predicted: predicted values
    
    Returns:
        dict of metrics
    """
    errors = actual - predicted
    
    metrics = {
        'rmse': np.sqrt(np.mean(errors ** 2)),
        'mae': np.mean(np.abs(errors)),
        'mean_error': np.mean(errors),
        'std_error': np.std(errors),
        'max_error': np.max(np.abs(errors)),
        'min_error': np.min(np.abs(errors)),
    }
    
    # Directional accuracy
    if len(actual) > 1:
        actual_direction = np.sign(np.diff(actual))
        pred_direction = np.sign(np.diff(predicted))
        da = (actual_direction == pred_direction).sum() / len(actual_direction)
        metrics['directional_accuracy'] = da
    else:
        metrics['directional_accuracy'] = np.nan
    
    return metrics


def show_comparative_analysis(result_dir="result", summary_dir="result_summary"):
    """
    Comparative Analysis & Statistical Testing Module
    
    Compares all forecasting models with statistical tests
    """
    
    st.title("📊 Comparative Analysis & Statistical Testing")
    st.markdown("""
    ### Model Comparison with Statistical Validation
    
    This module performs comprehensive comparison of all forecasting models:
    - **TVP-VAR** vs **LSTM** models
    - **Diebold-Mariano Test** for forecast accuracy
    - **Directional Accuracy Test** (binomial sign test)
    - **Publication-ready figures** and summary tables
    """)
    
    # Ensure directories exist
    comparison_dir = os.path.join(result_dir, "comparison")
    os.makedirs(comparison_dir, exist_ok=True)
    os.makedirs(summary_dir, exist_ok=True)
    
    # Check for required files
    tvpvar_pred_file = os.path.join(result_dir, "tvpvar", "tvpvar_predictions.csv")
    lstm_dir = os.path.join(result_dir, "lstm", "predictions")
    
    if not os.path.exists(tvpvar_pred_file):
        st.warning("⚠️ TVP-VAR predictions not found. Please run TVP-VAR modeling first.")
        return
    
    if not os.path.exists(lstm_dir):
        st.warning("⚠️ LSTM predictions not found. Please run LSTM modeling first.")
        return
    
    # Check for LSTM model files
    lstm_models = ['LSTM_A', 'LSTM_Base', 'LSTM_B']
    lstm_files = {model: os.path.join(lstm_dir, f"{model}_pred.csv") for model in lstm_models}
    
    missing_models = [model for model, file in lstm_files.items() if not os.path.exists(file)]
    if missing_models:
        st.warning(f"⚠️ Missing LSTM predictions: {', '.join(missing_models)}")
        st.info("Please run LSTM modeling for all three models first.")
        return
    
    st.success("✓ All required prediction files found!")
    
    # Run button
    if st.button("🚀 Run Comparative Analysis", type="primary"):
        
        with st.spinner("Running comprehensive comparative analysis..."):
            
            # Step 1: Load all predictions
            st.subheader("Step 1: Loading Predictions")
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                # Load TVP-VAR predictions
                status_text.text("Loading TVP-VAR predictions...")
                tvpvar_df = pd.read_csv(tvpvar_pred_file)
                tvpvar_df['date'] = pd.to_datetime(tvpvar_df['date'])
                
                # Load LSTM predictions
                lstm_dfs = {}
                for i, (model, file) in enumerate(lstm_files.items()):
                    status_text.text(f"Loading {model} predictions...")
                    df = pd.read_csv(file)
                    df['date'] = pd.to_datetime(df['date'])
                    lstm_dfs[model] = df
                    progress_bar.progress((i + 1) / len(lstm_models) * 0.2)
                
                st.success("✓ All predictions loaded successfully!")
                
                # Step 2: Align predictions
                st.subheader("Step 2: Aligning Predictions")
                status_text.text("Aligning all predictions by date...")
                
                # Start with TVP-VAR
                comparison_df = tvpvar_df[['date', 'actual', 'forecast']].copy()
                comparison_df.rename(columns={'forecast': 'tvpvar'}, inplace=True)
                
                # Merge LSTM predictions
                for model, df in lstm_dfs.items():
                    model_col = model.lower().replace('_', '')
                    # LSTM files use 'prediction' column, not 'forecast'
                    temp_df = df[['date', 'prediction']].copy()
                    temp_df.rename(columns={'prediction': model_col}, inplace=True)
                    comparison_df = comparison_df.merge(temp_df, on='date', how='inner')
                
                # Save comparison dataframe
                comparison_file = os.path.join(comparison_dir, "comparison_df.csv")
                comparison_df.to_csv(comparison_file, index=False)
                
                st.success(f"✓ Aligned {len(comparison_df)} predictions across all models")
                st.write(f"📁 Saved: {comparison_file}")
                
                progress_bar.progress(0.3)
                
                # Step 3: Calculate metrics for all models
                st.subheader("Step 3: Calculating Error Metrics")
                status_text.text("Computing comprehensive metrics...")
                
                actual = comparison_df['actual'].values
                models = ['tvpvar', 'lstma', 'lstmbase', 'lstmb']
                model_names = ['TVP-VAR', 'LSTM_A', 'LSTM_Base', 'LSTM_B']
                
                metrics_list = []
                
                for model, model_name in zip(models, model_names):
                    predicted = comparison_df[model].values
                    metrics = calculate_metrics(actual, predicted)
                    metrics['model'] = model_name
                    metrics_list.append(metrics)
                
                # Create metrics dataframe
                metrics_df = pd.DataFrame(metrics_list)
                metrics_df = metrics_df[['model', 'rmse', 'mae', 'mean_error', 'std_error', 
                                        'max_error', 'min_error', 'directional_accuracy']]
                
                # Round for readability
                for col in ['rmse', 'mae', 'mean_error', 'std_error', 'max_error', 'min_error']:
                    metrics_df[col] = metrics_df[col].round(6)
                metrics_df['directional_accuracy'] = metrics_df['directional_accuracy'].round(4)
                
                # Save metrics
                metrics_file = os.path.join(comparison_dir, "model_comparison_metrics.csv")
                metrics_df.to_csv(metrics_file, index=False)
                
                metrics_summary_file = os.path.join(summary_dir, "model_comparison_metrics.csv")
                metrics_df.to_csv(metrics_summary_file, index=False)
                
                st.success("✓ Metrics calculated for all models")
                st.dataframe(metrics_df, use_container_width=True)
                
                progress_bar.progress(0.5)
                
                # Step 4: Diebold-Mariano Test
                st.subheader("Step 4: Diebold-Mariano Test")
                status_text.text("Running DM tests for forecast accuracy...")
                
                # Define test pairs (LSTM_Base as benchmark)
                test_pairs = [
                    ('LSTM_Base', 'TVP-VAR', 'lstmbase', 'tvpvar'),
                    ('LSTM_Base', 'LSTM_A', 'lstmbase', 'lstma'),
                    ('LSTM_Base', 'LSTM_B', 'lstmbase', 'lstmb'),
                ]
                
                dm_results = []
                
                for model1_name, model2_name, model1_col, model2_col in test_pairs:
                    errors1 = actual - comparison_df[model1_col].values
                    errors2 = actual - comparison_df[model2_col].values
                    
                    dm_stat, p_value = diebold_mariano_test(errors1, errors2)
                    
                    # Determine conclusion
                    if p_value < 0.01:
                        conclusion = "Highly Significant"
                    elif p_value < 0.05:
                        conclusion = "Significant"
                    elif p_value < 0.10:
                        conclusion = "Marginally Significant"
                    else:
                        conclusion = "Not Significant"
                    
                    dm_results.append({
                        'model_1': model1_name,
                        'model_2': model2_name,
                        'dm_stat': round(dm_stat, 4),
                        'p_value': round(p_value, 4),
                        'conclusion': conclusion
                    })
                
                dm_df = pd.DataFrame(dm_results)
                
                # Save DM test results
                dm_file = os.path.join(comparison_dir, "dm_test_results.csv")
                dm_df.to_csv(dm_file, index=False)
                
                dm_summary_file = os.path.join(summary_dir, "dm_test_results.csv")
                dm_df.to_csv(dm_summary_file, index=False)
                
                st.success("✓ Diebold-Mariano tests completed")
                st.dataframe(dm_df, use_container_width=True)
                
                progress_bar.progress(0.65)
                
                # Step 5: Directional Accuracy Test
                st.subheader("Step 5: Directional Accuracy Test")
                status_text.text("Testing directional accuracy significance...")
                
                da_results = []
                
                for model, model_name in zip(models, model_names):
                    predicted = comparison_df[model].values
                    da, z_score, p_value, ci_lower, ci_upper = directional_accuracy_test(actual, predicted)
                    
                    # Determine conclusion
                    if p_value < 0.01:
                        conclusion = "Highly Significant"
                    elif p_value < 0.05:
                        conclusion = "Significant"
                    elif p_value < 0.10:
                        conclusion = "Marginally Significant"
                    else:
                        conclusion = "Not Significant"
                    
                    da_results.append({
                        'model': model_name,
                        'da': round(da, 4),
                        'z_score': round(z_score, 4),
                        'p_value': round(p_value, 4),
                        'ci_lower': round(ci_lower, 4),
                        'ci_upper': round(ci_upper, 4),
                        'conclusion': conclusion
                    })
                
                da_df = pd.DataFrame(da_results)
                
                # Save DA test results
                da_file = os.path.join(comparison_dir, "da_test_results.csv")
                da_df.to_csv(da_file, index=False)
                
                da_summary_file = os.path.join(summary_dir, "da_test_results.csv")
                da_df.to_csv(da_summary_file, index=False)
                
                st.success("✓ Directional accuracy tests completed")
                st.dataframe(da_df, use_container_width=True)
                
                progress_bar.progress(0.75)
                
                # Step 6: Create comparison plots
                st.subheader("Step 6: Generating Comparison Figures")
                status_text.text("Creating publication-ready figures...")
                
                # Set style
                sns.set_style("whitegrid")
                plt.rcParams['figure.dpi'] = 300
                
                # A. RMSE Comparison
                fig, ax = plt.subplots(figsize=(10, 6))
                rmse_data = metrics_df.sort_values('rmse')
                colors = ['#2ecc71' if x == rmse_data['rmse'].min() else '#3498db' for x in rmse_data['rmse']]
                ax.barh(rmse_data['model'], rmse_data['rmse'], color=colors)
                ax.set_xlabel('RMSE', fontsize=12, fontweight='bold')
                ax.set_title('Root Mean Squared Error Comparison', fontsize=14, fontweight='bold')
                ax.grid(axis='x', alpha=0.3)
                plt.tight_layout()
                rmse_file = os.path.join(summary_dir, "rmse_comparison.png")
                plt.savefig(rmse_file, dpi=300, bbox_inches='tight')
                plt.close()
                
                # B. MAE Comparison
                fig, ax = plt.subplots(figsize=(10, 6))
                mae_data = metrics_df.sort_values('mae')
                colors = ['#2ecc71' if x == mae_data['mae'].min() else '#3498db' for x in mae_data['mae']]
                ax.barh(mae_data['model'], mae_data['mae'], color=colors)
                ax.set_xlabel('MAE', fontsize=12, fontweight='bold')
                ax.set_title('Mean Absolute Error Comparison', fontsize=14, fontweight='bold')
                ax.grid(axis='x', alpha=0.3)
                plt.tight_layout()
                mae_file = os.path.join(summary_dir, "mae_comparison.png")
                plt.savefig(mae_file, dpi=300, bbox_inches='tight')
                plt.close()
                
                # C. Directional Accuracy Comparison
                fig, ax = plt.subplots(figsize=(10, 6))
                da_data = metrics_df.sort_values('directional_accuracy', ascending=False)
                colors = ['#2ecc71' if x == da_data['directional_accuracy'].max() else '#3498db' 
                         for x in da_data['directional_accuracy']]
                ax.barh(da_data['model'], da_data['directional_accuracy'], color=colors)
                ax.axvline(x=0.5, color='red', linestyle='--', linewidth=2, label='Random Guess (0.5)')
                ax.set_xlabel('Directional Accuracy', fontsize=12, fontweight='bold')
                ax.set_title('Directional Accuracy Comparison', fontsize=14, fontweight='bold')
                ax.legend()
                ax.grid(axis='x', alpha=0.3)
                plt.tight_layout()
                da_plot_file = os.path.join(summary_dir, "da_comparison.png")
                plt.savefig(da_plot_file, dpi=300, bbox_inches='tight')
                plt.close()
                
                # D. Error Distribution Comparison
                fig, ax = plt.subplots(figsize=(12, 6))
                for model, model_name in zip(models, model_names):
                    errors = actual - comparison_df[model].values
                    ax.hist(errors, bins=30, alpha=0.5, label=model_name, edgecolor='black')
                ax.axvline(x=0, color='red', linestyle='--', linewidth=2)
                ax.set_xlabel('Forecast Error', fontsize=12, fontweight='bold')
                ax.set_ylabel('Frequency', fontsize=12, fontweight='bold')
                ax.set_title('Error Distribution Comparison', fontsize=14, fontweight='bold')
                ax.legend()
                ax.grid(alpha=0.3)
                plt.tight_layout()
                error_dist_file = os.path.join(summary_dir, "error_distribution_comparison.png")
                plt.savefig(error_dist_file, dpi=300, bbox_inches='tight')
                plt.close()
                
                # E. Actual vs Forecast (All Models)
                fig, ax = plt.subplots(figsize=(14, 7))
                ax.plot(comparison_df['date'], actual, 'k-', linewidth=2, label='Actual', marker='o', markersize=3)
                
                colors_map = {'tvpvar': '#e74c3c', 'lstma': '#3498db', 
                             'lstmbase': '#2ecc71', 'lstmb': '#9b59b6'}
                for model, model_name in zip(models, model_names):
                    ax.plot(comparison_df['date'], comparison_df[model].values, 
                           linestyle='--', linewidth=1.5, label=model_name, 
                           color=colors_map[model], alpha=0.7)
                
                ax.set_xlabel('Date', fontsize=12, fontweight='bold')
                ax.set_ylabel('VNQ Log Return', fontsize=12, fontweight='bold')
                ax.set_title('Actual vs Forecast: All Models', fontsize=14, fontweight='bold')
                ax.legend(loc='best')
                ax.grid(alpha=0.3)
                plt.xticks(rotation=45)
                plt.tight_layout()
                forecast_file = os.path.join(summary_dir, "actual_vs_forecast_all_models.png")
                plt.savefig(forecast_file, dpi=300, bbox_inches='tight')
                plt.close()
                
                st.success("✓ All comparison figures generated")
                
                progress_bar.progress(0.9)
                
                # Step 7: Model Ranking
                st.subheader("Step 7: Final Model Ranking")
                status_text.text("Ranking models by performance...")
                
                # Rank by RMSE (lower is better)
                rmse_rank = metrics_df.sort_values('rmse').reset_index(drop=True)
                rmse_rank['rank'] = range(1, len(rmse_rank) + 1)
                rmse_rank = rmse_rank[['rank', 'model', 'rmse', 'mae', 'directional_accuracy']]
                rmse_rank.columns = ['rank', 'model', 'rmse', 'mae', 'da']
                
                # Save ranking
                ranking_file = os.path.join(summary_dir, "model_ranking.csv")
                rmse_rank.to_csv(ranking_file, index=False)
                
                st.success("✓ Model ranking completed")
                st.dataframe(rmse_rank, use_container_width=True)
                
                progress_bar.progress(1.0)
                status_text.text("Analysis complete!")
                
                # Display results
                st.success("🎉 Comparative analysis & statistical testing completed!")
                
                st.markdown("---")
                st.subheader("📊 Results Summary")
                
                # Create tabs for results
                tab1, tab2, tab3, tab4 = st.tabs([
                    "📈 Metrics Comparison", 
                    "📊 Statistical Tests",
                    "🎨 Visualizations",
                    "📁 Output Files"
                ])
                
                with tab1:
                    st.markdown("### Model Performance Metrics")
                    st.dataframe(metrics_df, use_container_width=True)
                    
                    st.markdown("### Model Ranking (by RMSE)")
                    st.dataframe(rmse_rank, use_container_width=True)
                
                with tab2:
                    st.markdown("### Diebold-Mariano Test Results")
                    st.dataframe(dm_df, use_container_width=True)
                    st.info("💡 Negative DM statistic: Model 1 is more accurate. Positive: Model 2 is more accurate.")
                    
                    st.markdown("### Directional Accuracy Test Results")
                    st.dataframe(da_df, use_container_width=True)
                    st.info("💡 Tests if directional accuracy is significantly better than random guess (0.5)")
                
                with tab3:
                    st.markdown("### RMSE Comparison")
                    st.image(rmse_file)
                    
                    st.markdown("### MAE Comparison")
                    st.image(mae_file)
                    
                    st.markdown("### Directional Accuracy Comparison")
                    st.image(da_plot_file)
                    
                    st.markdown("### Error Distribution")
                    st.image(error_dist_file)
                    
                    st.markdown("### Actual vs Forecast (All Models)")
                    st.image(forecast_file)
                
                with tab4:
                    st.markdown("### Output Files Generated")
                    
                    st.markdown("**Comparison Data:**")
                    st.code(f"✓ {comparison_file}")
                    
                    st.markdown("**Metrics & Tests:**")
                    st.code(f"✓ {metrics_file}\n✓ {dm_file}\n✓ {da_file}")
                    
                    st.markdown("**Summary Files:**")
                    st.code(f"✓ {metrics_summary_file}\n✓ {dm_summary_file}\n✓ {da_summary_file}\n✓ {ranking_file}")
                    
                    st.markdown("**Figures:**")
                    st.code(f"✓ {rmse_file}\n✓ {mae_file}\n✓ {da_plot_file}\n✓ {error_dist_file}\n✓ {forecast_file}")
                    
                    st.success(f"📁 Total: 14 files generated")
                
                # Key insights
                st.markdown("---")
                st.subheader("🔍 Key Insights")
                
                best_model = rmse_rank.iloc[0]['model']
                best_rmse = rmse_rank.iloc[0]['rmse']
                best_da = rmse_rank.iloc[0]['da']
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Best Model (RMSE)", best_model, f"{best_rmse:.6f}")
                
                with col2:
                    sig_dm = len(dm_df[dm_df['conclusion'].str.contains('Significant')])
                    st.metric("Significant DM Tests", f"{sig_dm}/{len(dm_df)}")
                
                with col3:
                    sig_da = len(da_df[da_df['conclusion'].str.contains('Significant')])
                    st.metric("Significant DA Tests", f"{sig_da}/{len(da_df)}")
                
                st.balloons()
                
            except Exception as e:
                st.error(f"Error during analysis: {str(e)}")
                import traceback
                st.code(traceback.format_exc())
