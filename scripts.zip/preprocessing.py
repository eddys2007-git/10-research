import streamlit as st
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from datetime import datetime, timedelta

def show_preprocessing(dataset_dir="dataset", prep_dir="data_prep"):
    st.title("Preprocessing Batch Dataset")
    st.markdown("""
    Proses batch untuk seluruh dataset yang ada. Pilih rentang data yang akan diproses:
    - **End Date**: Tanggal akhir data (YYYY-MM-DD)
    - **Duration**: Durasi data (misal: 5 years)
    """)
    
    # Input
    end_date = st.date_input("End Date", value=datetime.today())
    duration_years = st.number_input("Duration (years)", min_value=1, max_value=20, value=5)
    window_size = 60

    # Pastikan folder prep ada
    os.makedirs(prep_dir, exist_ok=True)

    if st.button("Proses Semua Dataset"):
        st.info("Memulai batch preprocessing...")
        files = [f for f in os.listdir(dataset_dir) if f.endswith('.csv')]
        if not files:
            st.warning("Tidak ada file dataset ditemukan.")
            return
        for file in files:
            ticker = file.replace('.csv', '')
            st.write(f"\n**Proses: {ticker}**")
            # Handle new yfinance format or traditional format
            file_path = os.path.join(dataset_dir, file)
            
            # First check if this is the new yfinance format by reading the first few lines
            try:
                with open(file_path, 'r') as f:
                    first_lines = [next(f) for _ in range(4) if f]
            except Exception as e:
                st.error(f"Error reading file {file}: {str(e)}")
                continue
            
            # Check if this is the new yfinance format
            is_new_format = False
            for line in first_lines:
                if 'Ticker' in line:
                    is_new_format = True
                    break
            
            if is_new_format:
                # This is the new yfinance format
                st.info(f"Mendeteksi format yfinance baru untuk {file}")
                
                try:
                    # Read the actual data (skip the header rows)
                    df = pd.read_csv(file_path, skiprows=3)
                    
                    # Debug information
                    st.write(f"Kolom yang terdeteksi: {', '.join(df.columns)}")
                    
                    # First column should be dates
                    if df.columns[0] != 'date':
                        df.rename(columns={df.columns[0]: 'date'}, inplace=True)
                    
                    # Find the 'close' equivalent column
                    if 'close' in df.columns:
                        close_col = 'close'
                    elif 'Close' in df.columns:
                        close_col = 'Close'  # Handle case where column is still 'Close'
                    elif 'Price' in df.columns:
                        close_col = 'Price'  # In new format, 'Price' is equivalent to 'close'
                    else:
                        # Use the second column as close price
                        close_col = df.columns[1]
                        st.info(f"Menggunakan kolom '{close_col}' sebagai data harga penutupan")
                    
                    # Create a new dataframe with just Date and Close
                    df = df[['date', close_col]].copy()
                    df.rename(columns={close_col: 'close'}, inplace=True)
                except Exception as e:
                    st.error(f"Error memproses file {file} dengan format baru: {str(e)}")
                    continue
            else:
                # Traditional format
                df = pd.read_csv(file_path)
                if 'date' not in df.columns:
                    df.reset_index(inplace=True)
                    if 'date' not in df.columns:
                        st.warning(f"File {file} tidak memiliki kolom 'date'. Lewati.")
                        continue
                
                # Make sure we have the close column
                if 'close' not in df.columns and 'Close' not in df.columns:
                    st.warning(f"File {file} tidak memiliki kolom 'close'. Lewati.")
                    continue
            # Handle case where column is still 'Close' instead of 'close'
            if 'close' not in df.columns and 'Close' in df.columns:
                df.rename(columns={'Close': 'close'}, inplace=True)
                
            df['date'] = pd.to_datetime(df['date'])
            df = df.sort_values('date')
            end_dt = pd.to_datetime(end_date)
            start_dt = end_dt - pd.DateOffset(years=duration_years)
            df = df[(df['date'] >= start_dt) & (df['date'] <= end_dt)]
            df = df[['date', 'close']].copy()
            df.dropna(inplace=True)
            # Log return
            df['log_return'] = np.log(df['close'] / df['close'].shift(1))
            df = df.dropna().reset_index(drop=True)
            # Rolling window
            X, y, date_idx = [], [], []
            for i in range(window_size, len(df)):
                X.append(df['close'].iloc[i-window_size:i].values)
                y.append(df['log_return'].iloc[i])
                date_idx.append(df['date'].iloc[i])
            if not X:
                st.warning(f"Data {ticker} tidak cukup untuk rolling window.")
                continue
            X = np.array(X)
            y = np.array(y)
            # Normalisasi
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            # Simpan hasil
            prep_df = pd.DataFrame(X_scaled, columns=[f"close_t-{window_size-i}" for i in range(window_size)])
            prep_df['log_return'] = y
            prep_df['date'] = date_idx
            prep_file = os.path.join(prep_dir, f"{ticker}_prep.csv")
            prep_df.to_csv(prep_file, index=False)
            st.success(f"Selesai: {prep_file} ({len(prep_df)} baris)")
        st.success("Batch preprocessing selesai.")
